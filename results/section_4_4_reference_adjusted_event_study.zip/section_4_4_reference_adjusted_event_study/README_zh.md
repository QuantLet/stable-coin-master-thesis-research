# Section 4.4：非美元稳定币上游调整与事件研究复现包

本包替代先前仅使用原始美元报价 FRM 的 4.4 版本。PAXG、EURS、IDRT 已在收益构造前分别按 XAUUSD、EURUSD、IDRUSD 调整，并从头重估滚动 Quantile-Lasso、GACV、币种 λ 和 FRM。

## 推荐使用的新版主图

- `figures/Figure_4_4_FRM_Event_Responses_Redesigned.*`：论文主图。左侧为五个历史事件的跨定义效应，右上为霍尔木兹口径分解，右下为稳健尺度和 leave-GUSD 检验。
- `code/05_plot_figure_4_4_redesign.R`：新版主图的独立复现脚本。
- `source_data/Source_Data_Figure_4_4_Redesigned.csv`：新版主图逐点源数据。
- 原四面板事件路径图仅保留为探索性附件，不建议继续作为正文主图。

## 最重要的文件

- `Section_4_4_Writing_Logic_and_Empirical_Design_zh.md`：中文写作逻辑、结果解释、创新点与投稿边界。
- `Section_4_4_Manuscript_Ready_EN.md`：可直接并入论文的英文 4.4 初稿。
- `figures/Figure_4_4_FRM_Event_Responses_Redesigned.*`：推荐正文主图，183 mm 双栏宽，含 SVG、PDF、600 dpi PNG/TIFF。
- `tables/Table_4_4a_Primary_Reference_Adjusted_Event_Effects_HAC90.csv`：调整后 11 币主结果。
- `tables/Table_4_4b_FRM_Definition_Robustness_HAC90.csv`：调整后、USD-only、原始美元及严格/尺度敏感性对比。
- `tables/Table_4_4c_Benchmark_Contamination_and_Composition_Contrasts_HAC90.csv`：同 11 币 raw/adjusted 基准污染检验。
- `tables/Table_4_4d_Embedded_USD_Target_Subindex_HAC90.csv`：完整网络内的 8 个 USD 目标 λ 子指数。
- `tables/Table_4_4e_USD_Only_Divergence_Decomposition_HAC90.csv`：非美元目标聚合与网络重估分解。
- `tables/Table_4_4f_Window_Robust_Scaling_Sensitivity_HAC90.csv`：窗口内 median/MAD 稳健标准化敏感性。
- `tables/Table_4_5b_Cross_Definition_Breadth_Concentration_and_Leave_One_Out.csv`：跨口径 λ 广度、集中度与正式 leave-one-out 推断。
- `tables/Table_4_6_Reference_Adjusted_Peg_Validation_HAC90.csv`：参考锚下行偏离和脱锚广度验证。
- `tables/Table_4_7_Hormuz_Macro_Mechanism_Descriptives.csv`：霍尔木兹期 Brent、WTI、VIX、DXY、S&P 500 与各 FRM 口径。

## 一键重跑

在本目录运行：

```bash
Rscript code/run_all.R
```

完整重跑包括四套系统：调整后 11 币、USD-only 8 币、调整后稳健标准化 11 币、USD-only 稳健标准化 8 币。共估计 130,616 个滚动目标回归，普通四核电脑需要数分钟。代码默认最多使用 4 个物理核心，也可在运行前设置 `FRM_CORES=2`。

只重估指定系统时可使用：

```bash
FRM_SPEC_FILTER=reference_adjusted_11 Rscript code/01_estimate_frm_definitions.R
```

可选值为 `reference_adjusted_11`、`usd_only_8`、`reference_adjusted_11_robust_scaled`、`usd_only_8_robust_scaled`。

## 估计口径

- 样本：2020-01-01 至 2026-05-31；FRM 为 2020-04-01 至 2026-05-31，共 2,252 个日历日。
- 滚动窗口：90 日；条件分位数：0.05；路径上限：25。
- 宏观变量：5 个；与原代码一致按同日变化进入模型。
- GACV：使用 `finite_rows[which.min(gacv[finite_rows])]` 修复过滤索引映射错误。
- 数值筛查：20 倍路径反转规则仅作为单独标注序列，不改变严格基准。
- 主事件模型：log(FRM) 全样本分段回归，年度固定效应、线性趋势、HAC(90)。
- 多重比较：每个结果/对比家族内对六事件进行 Holm 校正。
- 因果边界：事件时序关联，不是结构因果效应。

## 非美元参考资产处理

参考调整公式为 `adjusted price = token USD price / benchmark USD price`。基准 fixing 在周末和假日只延续最近过去观测，最长延续 11 天；不使用未来 fixing。调整没有新增缺失水平。详细 QA 位于：

- `qa/reference_adjustment_QA.csv`
- `qa/benchmark_carry_audit.csv`
- `qa/reference_adjustment_return_audit.csv`
- `qa/reference_adjustment_missingness.csv`

## 关键审计结果

- 调整后 11 币：36,032 个目标回归，0 失败；每日 11 个有效 λ。
- USD-only 8 币：29,276 个目标回归，0 失败；每日 8 个有效 λ。
- 两套稳健标准化系统分别再完成 36,032 和 29,276 个目标回归，均为 0 失败。
- 所有 FRM 系列均为 2,252 个有限正值。
- 六个事件的五段窗口完整且互不重叠；设计矩阵满秩。
- 图形实际由 R 解析并运行；Nature 静态预检为 13 PASS、1 个仅提示需实际 R 解析的 WARN、0 FAIL；实际 `Rscript parse()` 已通过。
- 最终图经人工视觉检查，物理宽度 183 mm、基础字体 8 pt、矢量文字可编辑、光栅输出 600 dpi。

## 最重要的结果边界

SVB 是跨定义最稳健的正向系统压力。FTX 在所有定义中方向为正，但稳健标准化后的置信区间跨零。Terra 不显示正向 FRM 传染。霍尔木兹结果对网络边界具有结构性敏感：完整调整后 11 币 FRM 下降，USD-only 系统上升，原始美元口径不显著。因此论文应写成“美元锚定子网络出现更高的共同下尾压力，但混合参考资产系统不存在定义不变的上升”，不能写成全市场单方向结论。

## 目录结构

- `code/`：参考面板构造、四套 FRM 全量重估、事件研究、出图与一键脚本。
- `source_data/raw/`：原始价格、市值、宏观、参考资产与旧口径对照数据。
- `source_data/prepared/`：调整价格、USD-only 价格、基准日历和三币逐日变换。
- `source_data/frm/`：四套 FRM、λ、目标回归诊断与元数据。
- `tables/`：主表与补充表。
- `figures/`：投稿图和图注。
- `qa/`：变换、估计、统计、图形与会话审计。
