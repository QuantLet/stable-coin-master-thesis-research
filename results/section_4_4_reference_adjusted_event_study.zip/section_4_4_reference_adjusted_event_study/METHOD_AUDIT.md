# Method audit and disclosure boundary

## Preserved from the audited FRM reconstruction

- Calendar-daily panels; 90-observation trailing window; conditional quantile 0.05; maximum 25 path updates.
- Eleven stablecoins and five contemporaneous macro-financial variables in the inclusive system.
- Minimum finite GACV selection with the corrected mapping back to the original path row.
- Date-specific deterministic seeds for the estimator's tie-breaking jitter.
- Equal-weight mean of coin-target lambdas as the daily FRM.
- Non-finite stablecoin log returns set to zero and backward macro carry from a future observation, as in the supplied wrapper.

The last two rules are retained for comparability, not endorsed as ideal missing-data treatment. In particular, the macro rule can introduce look-ahead information and must be disclosed.

## Upstream economic correction

The main system replaces raw USD-quoted prices with reference-unit prices before returns are computed:

- PAXG/XAUUSD;
- EURS/EURUSD;
- IDRT/IDRUSD;
- unit USD benchmark for the other eight coins.

Reference fixings use past-only carry across non-trading days. This transformation changes the estimation input and therefore requires full re-estimation of every rolling Quantile-Lasso path, lambda, and FRM value.

## Separately labelled robustness definitions

- `usd_only_8`: a newly estimated eight-coin system, not a post hoc subsetting of the eleven-coin FRM.
- `raw_usd_11`: the prior raw-price system, retained only for benchmark-definition comparison.
- `robust_scaled`: median centering and MAD scaling within each trailing 90-day window for all active stablecoin and macro returns, with SD then unit fallback. This is a methodological extension, not the supplied FRM estimator.
- `embedded USD target subindex`: the mean of the eight USD-target lambdas estimated inside the full adjusted network. It is a decomposition diagnostic, not an independently estimated network.

## Statistical safeguards

- Primary outcome and event list are fixed before inspecting the reference-adjusted event estimates.
- The unit of analysis is the calendar day.
- HAC(90) is primary because rolling 90-day estimates induce serial dependence; HAC(30/60/120) is reported.
- Holm correction is applied across the six-event family within each outcome and contrast.
- Effect sizes, 95% confidence intervals, exact p values, adjusted p values, and leave-one-out results are retained.
- Results are described as event-timed associations, not causal effects.

## Data-source disclosures

- EURUSD uses an official Federal Reserve/FRED daily series.
- IDRUSD is the exact inverse of Bank Indonesia JISDOR (USDIDR).
- XAUUSD uses a public Westmetall display of London gold fixings with documented corrections. It is suitable for the current reproducibility analysis but should be replaced by a licensed LBMA/IBA export if the target journal or reviewer requires an official primary gold fixing.
- Four stablecoin price levels are missing in the complete panel: three IDRT cells and one sUSD cell. No price-level interpolation is introduced.
- The macro extension is heterogeneous: public equivalent series, formula reconstruction, and calibrated proxies are combined after the original QuantLet segment.

## Interpretation limits exposed by the new results

Reference adjustment removes movements of the economic benchmark but does not guarantee comparable residual volatility or penalty scale across tokens. In the Iran–Hormuz baseline, IDRT dominates the adjusted full-system lambda magnitude; in the standalone USD-only system, GUSD dominates the event-window increase. The opposite signs of the adjusted full system and the USD-only system therefore reflect both aggregation and network-boundary effects. A broad market claim is not warranted when conclusions reverse across these definitions.

UST is absent from the FRM panel, so the Terra exercise measures transmission to the sampled surviving coins. The daily design cannot resolve intraday event timing or weekend microstructure. The event list is frozen for this analysis but is not historically preregistered. These limitations should be stated rather than converted into causal language.
