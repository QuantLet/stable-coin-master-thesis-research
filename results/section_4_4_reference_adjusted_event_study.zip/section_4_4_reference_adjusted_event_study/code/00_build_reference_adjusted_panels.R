#!/usr/bin/env Rscript

# Build stablecoin price panels for three FRM definitions:
#   1) reference-adjusted eleven-coin panel (main specification),
#   2) USD-pegged eight-coin panel (sample-composition robustness), and
#   3) raw USD-quoted eleven-coin panel (legacy comparison, supplied unchanged).
#
# The non-USD transformation is performed at the price level before returns,
# rolling windows, Quantile Lasso, GACV selection, lambdas, or FRM aggregation.

options(stringsAsFactors = FALSE, digits = 15, warn = 1, scipen = 999)

script_path <- function() {
  hit <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (!length(hit)) stop("Run this file with Rscript.")
  normalizePath(sub("^--file=", "", hit[1]), mustWork = TRUE)
}

code_dir <- dirname(script_path())
bundle_dir <- dirname(code_dir)
raw_dir <- file.path(bundle_dir, "source_data", "raw")
out_dir <- file.path(bundle_dir, "source_data", "prepared")
qa_dir <- file.path(bundle_dir, "qa")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

write_csv <- function(x, path) {
  write.csv(x, path, row.names = FALSE, quote = TRUE, na = "", fileEncoding = "UTF-8")
}

parse_panel_date <- function(x) {
  out <- suppressWarnings(as.Date(x, "%m/%d/%Y"))
  miss <- is.na(out)
  if (any(miss)) out[miss] <- suppressWarnings(as.Date(x[miss]))
  if (anyNA(out)) stop("Date parsing failed.")
  out
}

price_path <- file.path(raw_dir, "Stable_Price_20260531.csv")
if (!file.exists(price_path)) stop("Missing raw stablecoin price panel: ", price_path)
prices <- read.csv(price_path, check.names = FALSE, stringsAsFactors = FALSE)
prices[[1]] <- parse_panel_date(prices[[1]])
names(prices)[1] <- "date"
prices <- prices[order(prices$date), ]

expected_dates <- seq(as.Date("2020-01-01"), as.Date("2026-05-31"), by = "day")
if (!identical(prices$date, expected_dates)) stop("Raw price panel is not a complete calendar-daily panel.")
if (anyDuplicated(prices$date)) stop("Raw price dates are duplicated.")

coin_map <- data.frame(
  column = c(
    "usd_coin", "binance_usd", "gemini_dollar", "stasis_eurs",
    "rupiah_token", "tether", "nusd", "pax_gold", "true_usd",
    "paxos_standard", "dai"
  ),
  symbol = c("USDC", "BUSD", "GUSD", "EURS", "IDRT", "USDT", "sUSD",
             "PAXG", "TUSD", "USDP", "DAI"),
  benchmark = c("USD", "USD", "USD", "EURUSD", "IDRUSD", "USD", "USD",
                "XAUUSD", "USD", "USD", "USD"),
  specification_role = c(
    "USD-only and adjusted", "USD-only and adjusted", "USD-only and adjusted",
    "adjusted only", "adjusted only", "USD-only and adjusted",
    "USD-only and adjusted", "adjusted only", "USD-only and adjusted",
    "USD-only and adjusted", "USD-only and adjusted"
  ),
  stringsAsFactors = FALSE
)
if (!identical(names(prices)[-1], coin_map$column)) {
  stop("Unexpected stablecoin columns or ordering in raw price panel.")
}

read_benchmark <- function(key) {
  path <- file.path(raw_dir, paste0(key, ".csv"))
  if (!file.exists(path)) stop("Missing benchmark file: ", path)
  x <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  if (!all(c("date", "value") %in% names(x))) stop("Malformed benchmark: ", path)
  x$date <- as.Date(x$date)
  x$value <- suppressWarnings(as.numeric(x$value))
  x <- x[!is.na(x$date) & is.finite(x$value) & x$value > 0, c("date", "value")]
  x <- x[order(x$date), ]
  if (anyDuplicated(x$date)) stop("Duplicate dates in benchmark: ", key)
  x
}

# Past-information-only carry-forward. This is intentionally unrestricted by a
# five-day threshold: official FX and gold fixings are held constant across
# weekends and local-market holidays, never replaced with a future fixing.
align_benchmark_past <- function(x, dates, key) {
  pos <- findInterval(as.numeric(dates), as.numeric(x$date))
  if (any(pos < 1L)) stop("Benchmark has no observation on or before sample start: ", key)
  used_date <- x$date[pos]
  value <- x$value[pos]
  data.frame(
    date = dates,
    benchmark = key,
    value = value,
    source_observation_date = used_date,
    observed_on_date = used_date == dates,
    days_since_observation = as.integer(dates - used_date),
    stringsAsFactors = FALSE
  )
}

bench_list <- lapply(c("XAUUSD", "EURUSD", "IDRUSD"), function(key) {
  align_benchmark_past(read_benchmark(key), prices$date, key)
})
names(bench_list) <- c("XAUUSD", "EURUSD", "IDRUSD")
benchmark_long <- do.call(rbind, bench_list)
rownames(benchmark_long) <- NULL
write_csv(benchmark_long, file.path(out_dir, "reference_benchmark_panel.csv"))

benchmark_wide <- data.frame(date = prices$date)
for (key in names(bench_list)) benchmark_wide[[key]] <- bench_list[[key]]$value

adjusted <- prices
for (i in seq_len(nrow(coin_map))) {
  nm <- coin_map$column[i]
  key <- coin_map$benchmark[i]
  adjusted[[nm]] <- suppressWarnings(as.numeric(adjusted[[nm]]))
  if (key != "USD") adjusted[[nm]] <- adjusted[[nm]] / benchmark_wide[[key]]
}

usd_columns <- coin_map$column[coin_map$benchmark == "USD"]
adjusted_path <- file.path(out_dir, "Stable_Price_reference_adjusted_11.csv")
usd_only_path <- file.path(out_dir, "Stable_Price_USD_only_8.csv")
write_csv(adjusted, adjusted_path)
write_csv(adjusted[, c("date", usd_columns), drop = FALSE], usd_only_path)
write_csv(coin_map, file.path(out_dir, "stablecoin_reference_map.csv"))

daily_adjustment <- do.call(rbind, lapply(which(coin_map$benchmark != "USD"), function(i) {
  nm <- coin_map$column[i]
  key <- coin_map$benchmark[i]
  data.frame(
    date = prices$date,
    column = nm,
    symbol = coin_map$symbol[i],
    benchmark = key,
    raw_price_usd = suppressWarnings(as.numeric(prices[[nm]])),
    benchmark_usd = benchmark_wide[[key]],
    reference_adjusted_price = adjusted[[nm]],
    stringsAsFactors = FALSE
  )
}))
write_csv(daily_adjustment, file.path(out_dir, "non_usd_reference_adjustment_daily.csv"))

return_audit <- do.call(rbind, lapply(which(coin_map$benchmark != "USD"), function(i) {
  nm <- coin_map$column[i]
  key <- coin_map$benchmark[i]
  r_raw <- diff(log(suppressWarnings(as.numeric(prices[[nm]]))))
  r_benchmark <- diff(log(benchmark_wide[[key]]))
  r_adjusted <- diff(log(adjusted[[nm]]))
  ok <- is.finite(r_raw) & is.finite(r_benchmark) & is.finite(r_adjusted)
  data.frame(
    column = nm,
    symbol = coin_map$symbol[i],
    benchmark = key,
    finite_return_days = sum(ok),
    sd_raw_usd_return = sd(r_raw[ok]),
    sd_benchmark_return = sd(r_benchmark[ok]),
    sd_reference_adjusted_return = sd(r_adjusted[ok]),
    correlation_raw_with_benchmark = cor(r_raw[ok], r_benchmark[ok]),
    correlation_raw_with_adjusted = cor(r_raw[ok], r_adjusted[ok]),
    max_return_identity_error = max(abs(r_raw[ok] - r_benchmark[ok] - r_adjusted[ok])),
    stringsAsFactors = FALSE
  )
}))
write_csv(return_audit, file.path(qa_dir, "reference_adjustment_return_audit.csv"))

missingness <- do.call(rbind, lapply(seq_len(nrow(coin_map)), function(i) {
  nm <- coin_map$column[i]
  raw_v <- suppressWarnings(as.numeric(prices[[nm]]))
  adj_v <- suppressWarnings(as.numeric(adjusted[[nm]]))
  data.frame(
    column = nm,
    symbol = coin_map$symbol[i],
    benchmark = coin_map$benchmark[i],
    raw_missing_levels = sum(!is.finite(raw_v)),
    adjusted_missing_levels = sum(!is.finite(adj_v)),
    raw_nonfinite_log_returns = sum(!is.finite(diff(log(raw_v)))),
    adjusted_nonfinite_log_returns = sum(!is.finite(diff(log(adj_v)))),
    stringsAsFactors = FALSE
  )
}))
write_csv(missingness, file.path(qa_dir, "reference_adjustment_missingness.csv"))

carry_audit <- do.call(rbind, lapply(names(bench_list), function(key) {
  x <- bench_list[[key]]
  data.frame(
    benchmark = key,
    sample_days = nrow(x),
    observed_fixing_days = sum(x$observed_on_date),
    carried_forward_days = sum(!x$observed_on_date),
    maximum_days_since_observation = max(x$days_since_observation),
    first_source_observation_used = format(min(x$source_observation_date)),
    last_source_observation_used = format(max(x$source_observation_date)),
    carry_rule = "last observation carried forward using past information only",
    stringsAsFactors = FALSE
  )
}))
write_csv(carry_audit, file.path(qa_dir, "benchmark_carry_audit.csv"))

usd_exact_error <- max(abs(
  as.matrix(adjusted[, usd_columns, drop = FALSE]) -
    as.matrix(prices[, usd_columns, drop = FALSE])
), na.rm = TRUE)
formula_error <- max(return_audit$max_return_identity_error)
qa <- data.frame(
  check = c(
    "calendar_daily_complete", "input_columns_match_declared_map",
    "benchmarks_use_no_future_information", "benchmarks_complete_after_past_carry",
    "usd_coin_prices_unchanged", "return_identity_holds_for_non_usd_coins",
    "adjustment_does_not_create_extra_missing_levels", "usd_only_contains_eight_coins"
  ),
  status = c(
    "PASS", "PASS",
    if (all(benchmark_long$source_observation_date <= benchmark_long$date)) "PASS" else "FAIL",
    if (all(is.finite(benchmark_long$value))) "PASS" else "FAIL",
    if (usd_exact_error < 1e-14) "PASS" else "FAIL",
    if (formula_error < 1e-12) "PASS" else "FAIL",
    if (all(missingness$adjusted_missing_levels == missingness$raw_missing_levels)) "PASS" else "FAIL",
    if (length(usd_columns) == 8L) "PASS" else "FAIL"
  ),
  detail = c(
    paste(format(min(prices$date)), "to", format(max(prices$date)), "with", nrow(prices), "days"),
    paste(coin_map$symbol, collapse = ", "),
    paste("maximum carry", max(benchmark_long$days_since_observation), "days"),
    paste(sum(is.finite(benchmark_long$value)), "of", nrow(benchmark_long), "finite"),
    format(usd_exact_error, scientific = TRUE),
    format(formula_error, scientific = TRUE),
    paste("raw/adjusted missing level totals", sum(missingness$raw_missing_levels), "/", sum(missingness$adjusted_missing_levels)),
    paste(coin_map$symbol[coin_map$benchmark == "USD"], collapse = ", ")
  ),
  stringsAsFactors = FALSE
)
write_csv(qa, file.path(qa_dir, "reference_adjustment_QA.csv"))
if (any(qa$status != "PASS")) stop("Reference-adjustment QA failed.")

metadata <- c(
  "main_specification=eleven stablecoins with non-USD prices divided by their reference benchmark before log differencing",
  "non_usd_mapping=PAXG/XAUUSD; EURS/EURUSD; IDRT/IDRUSD",
  "usd_robustness=eight USD-pegged stablecoins re-estimated as a separate system",
  "legacy_comparison=raw USD-quoted eleven-coin FRM retained only as a supplementary benchmark",
  "benchmark_calendar_rule=last observed fixing carried forward using past information only",
  "missing_price_rule=price-level missingness retained; the estimator later applies the supplied non-finite-return-to-zero rule",
  paste0("raw_price_md5=", unname(tools::md5sum(price_path))),
  paste0("adjusted_price_md5=", unname(tools::md5sum(adjusted_path))),
  paste0("usd_only_price_md5=", unname(tools::md5sum(usd_only_path)))
)
writeLines(metadata, file.path(qa_dir, "reference_adjustment_metadata.txt"), useBytes = TRUE)
message("Reference-adjusted and USD-only price panels created: ", out_dir)
