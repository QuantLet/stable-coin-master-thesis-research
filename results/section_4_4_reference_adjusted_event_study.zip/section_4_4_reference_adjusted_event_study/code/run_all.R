#!/usr/bin/env Rscript

options(warn = 1)
hit <- grep("^--file=", commandArgs(FALSE), value = TRUE)
if (!length(hit)) stop("Run this file with Rscript.")
code_dir <- dirname(normalizePath(sub("^--file=", "", hit[1]), mustWork = TRUE))
rscript <- file.path(R.home("bin"), "Rscript")
steps <- c(
  "00_build_reference_adjusted_panels.R",
  "01_estimate_frm_definitions.R",
  "02_event_study_three_definitions.R",
  "03_plot_reference_adjusted_event_study.R",
  "05_plot_figure_4_4_redesign.R",
  "04_finalize_bundle_QA.R"
)
for (step in steps) {
  message("\n>>> ", step)
  status <- system2(rscript, file.path(code_dir, step))
  if (!identical(status, 0L)) stop("Pipeline failed at: ", step)
}
message("\nReference-adjusted Section 4.4 pipeline completed.")
