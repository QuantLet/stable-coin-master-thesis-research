#!/usr/bin/env Rscript

# Section 4.4 event study after upstream reference-asset adjustment.
# Primary inference: reference-adjusted 11-coin, numerically screened FRM.
# Robustness: independently re-estimated USD-only 8-coin FRM, strict GACV
# variants, and the legacy raw-USD 11-coin FRM.

options(stringsAsFactors = FALSE, digits = 15, warn = 1, scipen = 999)

script_path <- function() {
  hit <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (!length(hit)) stop("Run this file with Rscript.")
  normalizePath(sub("^--file=", "", hit[1]), mustWork = TRUE)
}

code_dir <- dirname(script_path())
bundle_dir <- dirname(code_dir)
raw_dir <- file.path(bundle_dir, "source_data", "raw")
frm_dir <- file.path(bundle_dir, "source_data", "frm")
table_dir <- file.path(bundle_dir, "tables")
qa_dir <- file.path(bundle_dir, "qa")
config_dir <- file.path(bundle_dir, "config")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

write_csv <- function(x, path) {
  write.csv(x, path, row.names = FALSE, quote = TRUE, na = "", fileEncoding = "UTF-8")
}

read_csv_checked <- function(path, required = character()) {
  if (!file.exists(path)) stop("Missing input: ", path)
  x <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  absent <- setdiff(required, names(x))
  if (length(absent)) stop("Missing columns in ", basename(path), ": ", paste(absent, collapse = ", "))
  x
}

parse_date <- function(x) {
  out <- suppressWarnings(as.Date(x))
  if (anyNA(out)) stop("Unparseable dates detected.")
  out
}

events <- read_csv_checked(
  file.path(config_dir, "events_primary.csv"),
  c("event_id", "event_label", "event_date", "shock_type", "origin")
)
events$event_date <- parse_date(events$event_date)

series_manifest <- data.frame(
  series_id = c(
    "adjusted_screened", "adjusted_strict", "usd_only_screened",
    "usd_only_strict", "raw_usd_screened", "raw_usd_strict",
    "adjusted_robust_scaled", "usd_only_robust_scaled"
  ),
  series_label = c(
    "Reference-adjusted 11-coin FRM (screened)",
    "Reference-adjusted 11-coin FRM (strict)",
    "USD-only 8-coin FRM (screened)",
    "USD-only 8-coin FRM (strict)",
    "Raw USD-quoted 11-coin FRM (screened)",
    "Raw USD-quoted 11-coin FRM (strict)",
    "Reference-adjusted 11-coin FRM (window-robust-scaled)",
    "USD-only 8-coin FRM (window-robust-scaled)"
  ),
  definition = c(
    "reference-adjusted", "reference-adjusted", "USD-only", "USD-only",
    "raw USD-quoted", "raw USD-quoted", "reference-adjusted robust-scaled",
    "USD-only robust-scaled"
  ),
  coin_sample = c("11 coins", "11 coins", "8 USD-pegged coins", "8 USD-pegged coins",
                  "11 coins", "11 coins", "11 coins", "8 USD-pegged coins"),
  path_rule = c("numerically screened", "strict minimum GACV", "numerically screened",
                "strict minimum GACV", "numerically screened", "strict minimum GACV",
                "numerically screened after window-local median/MAD scaling",
                "numerically screened after window-local median/MAD scaling"),
  role = c("primary", "numerical robustness", "sample robustness", "joint robustness",
           "legacy benchmark", "legacy joint robustness", "scale sensitivity",
           "scale-and-sample sensitivity"),
  file = c(
    file.path(frm_dir, "reference_adjusted_11", "frm_numerical_screened.csv"),
    file.path(frm_dir, "reference_adjusted_11", "frm_strict.csv"),
    file.path(frm_dir, "usd_only_8", "frm_numerical_screened.csv"),
    file.path(frm_dir, "usd_only_8", "frm_strict.csv"),
    file.path(raw_dir, "frm_numerical_sensitivity.csv"),
    file.path(raw_dir, "frm_strict.csv"),
    file.path(frm_dir, "reference_adjusted_11_robust_scaled", "frm_numerical_screened.csv"),
    file.path(frm_dir, "usd_only_8_robust_scaled", "frm_numerical_screened.csv")
  ),
  stringsAsFactors = FALSE
)
write_csv(series_manifest[, setdiff(names(series_manifest), "file")],
          file.path(qa_dir, "FRM_definition_manifest.csv"))

frm_list <- lapply(seq_len(nrow(series_manifest)), function(i) {
  x <- read_csv_checked(series_manifest$file[i], c("date", "frm"))
  x$date <- parse_date(x$date)
  x$frm <- suppressWarnings(as.numeric(x$frm))
  if (anyDuplicated(x$date) || any(!is.finite(x$frm)) || any(x$frm <= 0)) {
    stop("Invalid FRM series: ", series_manifest$series_id[i])
  }
  names(x)[names(x) == "frm"] <- series_manifest$series_id[i]
  x[, c("date", series_manifest$series_id[i])]
})

lambdas <- read_csv_checked(
  file.path(frm_dir, "reference_adjusted_11", "lambdas_numerical_screened.csv"), "date"
)
lambdas$date <- parse_date(lambdas$date)
if (anyDuplicated(lambdas$date)) stop("Adjusted lambda dates are duplicated.")

coin_columns <- setdiff(names(lambdas), "date")
coin_labels <- c(
  usd_coin = "USDC", binance_usd = "BUSD", gemini_dollar = "GUSD",
  stasis_eurs = "EURS", rupiah_token = "IDRT", tether = "USDT",
  nusd = "sUSD", pax_gold = "PAXG", true_usd = "TUSD",
  paxos_standard = "USDP", dai = "DAI"
)
if (!all(coin_columns %in% names(coin_labels))) stop("Unmapped adjusted lambda columns.")
lambda_mat <- as.matrix(lambdas[, coin_columns, drop = FALSE])
storage.mode(lambda_mat) <- "numeric"
if (any(lambda_mat < 0, na.rm = TRUE)) stop("Negative lambdas detected.")
lambda_total <- rowSums(lambda_mat, na.rm = TRUE)
lambda_share <- lambda_mat / lambda_total
lambda_share[!is.finite(lambda_share)] <- NA_real_
lambda_hhi <- rowSums(lambda_share^2, na.rm = TRUE)
lambda_max_share <- apply(lambda_share, 1, max, na.rm = TRUE)
lambda_daily <- data.frame(
  date = lambdas$date,
  lambda_hhi = lambda_hhi,
  lambda_effective_n = 1 / lambda_hhi,
  lambda_max_share = lambda_max_share,
  adjusted_full_network_usd_target_subindex = rowMeans(
    lambda_mat[, coin_columns %in% c(
      "usd_coin", "binance_usd", "gemini_dollar", "tether",
      "nusd", "true_usd", "paxos_standard", "dai"
    ), drop = FALSE],
    na.rm = TRUE
  ),
  stringsAsFactors = FALSE
)

peg <- read_csv_checked(
  file.path(raw_dir, "peg_panel_minimal.csv"),
  c("date", "symbol", "signed_deviation_bps", "absolute_deviation_bps")
)
peg$date <- parse_date(peg$date)
peg$signed_deviation_bps <- suppressWarnings(as.numeric(peg$signed_deviation_bps))
peg$absolute_deviation_bps <- suppressWarnings(as.numeric(peg$absolute_deviation_bps))
peg$downside_bps <- pmax(-peg$signed_deviation_bps, 0)
peg$depeg_1pct <- is.finite(peg$signed_deviation_bps) & peg$signed_deviation_bps <= -100
peg_split <- split(peg, peg$date)
peg_daily <- do.call(rbind, lapply(peg_split, function(z) {
  data.frame(
    date = z$date[1],
    peg_n = sum(is.finite(z$signed_deviation_bps)),
    peg_mean_downside_bps = mean(z$downside_bps, na.rm = TRUE),
    peg_median_abs_bps = median(z$absolute_deviation_bps, na.rm = TRUE),
    peg_max_downside_bps = max(z$downside_bps, na.rm = TRUE),
    peg_depeg_breadth_1pct = sum(z$depeg_1pct, na.rm = TRUE),
    stringsAsFactors = FALSE
  )
}))
rownames(peg_daily) <- NULL
peg_daily$date <- parse_date(peg_daily$date)

daily <- Reduce(function(x, y) merge(x, y, by = "date", all = FALSE),
                c(frm_list, list(lambda_daily, peg_daily)))
daily <- daily[order(daily$date), ]
for (id in series_manifest$series_id) daily[[paste0("log_", id)]] <- log(daily[[id]])
daily$time_years <- as.numeric(daily$date - min(daily$date)) / 365.25
daily$year <- factor(format(daily$date, "%Y"))

stages <- list(
  baseline = -60:-8,
  anticipation = -7:-1,
  acute = 0:7,
  transmission = 8:30,
  persistence = 31:60
)
stage_col <- function(event_id, stage) paste0("ev_", event_id, "__", stage)
stage_matrix <- matrix(0, nrow = nrow(daily), ncol = nrow(events) * length(stages))
stage_names <- character(ncol(stage_matrix))
cc <- 0L
for (i in seq_len(nrow(events))) {
  event_time <- as.integer(daily$date - events$event_date[i])
  for (stage in names(stages)) {
    cc <- cc + 1L
    stage_matrix[, cc] <- as.integer(event_time %in% stages[[stage]])
    stage_names[cc] <- stage_col(events$event_id[i], stage)
  }
}
colnames(stage_matrix) <- stage_names
if (any(rowSums(stage_matrix) > 1L)) stop("Primary event windows overlap.")

year_matrix <- model.matrix(~ year, data = daily)
X <- cbind(year_matrix, time_years = daily$time_years, stage_matrix)
if (qr(X)$rank != ncol(X)) stop("Event-study design matrix is rank deficient.")

newey_west_vcov <- function(X, residuals, lag = 90L) {
  n <- nrow(X); k <- ncol(X)
  lag <- min(as.integer(lag), n - 1L)
  Xu <- X * as.numeric(residuals)
  meat <- crossprod(Xu)
  if (lag > 0L) {
    for (ell in seq_len(lag)) {
      weight <- 1 - ell / (lag + 1)
      gamma <- crossprod(Xu[(ell + 1L):n, , drop = FALSE],
                         Xu[seq_len(n - ell), , drop = FALSE])
      meat <- meat + weight * (gamma + t(gamma))
    }
  }
  bread <- solve(crossprod(X))
  (n / (n - k)) * bread %*% meat %*% bread
}

contrast_vector <- function(event_id, contrast_name, coefficient_names) {
  cvec <- setNames(rep(0, length(coefficient_names)), coefficient_names)
  b <- stage_col(event_id, "baseline")
  a <- stage_col(event_id, "anticipation")
  u <- stage_col(event_id, "acute")
  t <- stage_col(event_id, "transmission")
  p <- stage_col(event_id, "persistence")
  if (contrast_name == "anticipation_vs_baseline") {
    cvec[a] <- 1; cvec[b] <- -1
  } else if (contrast_name == "acute_0_7_vs_baseline") {
    cvec[u] <- 1; cvec[b] <- -1
  } else if (contrast_name == "acute_to_transmission_0_30_vs_baseline") {
    cvec[u] <- length(stages$acute) / 31
    cvec[t] <- length(stages$transmission) / 31
    cvec[b] <- -1
  } else if (contrast_name == "persistence_31_60_vs_baseline") {
    cvec[p] <- 1; cvec[b] <- -1
  } else stop("Unknown contrast: ", contrast_name)
  cvec
}

fit_event_model <- function(y, series_id, hac_lag = 90L) {
  if (any(!is.finite(y))) stop("Outcome contains non-finite values: ", series_id)
  fit <- lm.fit(x = X, y = y)
  beta <- setNames(as.numeric(fit$coefficients), colnames(X))
  vcov <- newey_west_vcov(X, fit$residuals, lag = hac_lag)
  dimnames(vcov) <- list(colnames(X), colnames(X))
  contrast_names <- c(
    "anticipation_vs_baseline", "acute_0_7_vs_baseline",
    "acute_to_transmission_0_30_vs_baseline", "persistence_31_60_vs_baseline"
  )
  out <- do.call(rbind, lapply(events$event_id, function(eid) {
    do.call(rbind, lapply(contrast_names, function(cn) {
      cvec <- contrast_vector(eid, cn, names(beta))
      estimate <- sum(cvec * beta)
      se <- sqrt(as.numeric(t(cvec) %*% vcov %*% cvec))
      z <- estimate / se
      data.frame(
        series_id = series_id,
        hac_lag = hac_lag,
        event_id = eid,
        contrast = cn,
        estimate_log = estimate,
        se_log = se,
        z = z,
        p_value = 2 * pnorm(abs(z), lower.tail = FALSE),
        effect_pct = 100 * expm1(estimate),
        ci95_low_pct = 100 * expm1(estimate - qnorm(0.975) * se),
        ci95_high_pct = 100 * expm1(estimate + qnorm(0.975) * se),
        stringsAsFactors = FALSE
      )
    }))
  }))
  out$adj_r_squared <- 1 - (sum(fit$residuals^2) / (nrow(X) - ncol(X))) /
    (sum((y - mean(y))^2) / (length(y) - 1))
  out
}

effects <- do.call(rbind, lapply(series_manifest$series_id, function(id) {
  fit_event_model(daily[[paste0("log_", id)]], id, 90L)
}))
effects$p_holm_six_events <- ave(
  effects$p_value, effects$series_id, effects$contrast,
  FUN = function(v) p.adjust(v, method = "holm")
)
effects <- merge(effects, series_manifest[, setdiff(names(series_manifest), "file")],
                 by = "series_id", all.x = TRUE, sort = FALSE)
effects <- merge(effects, events[, c("event_id", "event_label", "event_date", "shock_type", "origin")],
                 by = "event_id", all.x = TRUE, sort = FALSE)
effects <- effects[, c(
  "series_id", "series_label", "definition", "coin_sample", "path_rule", "role",
  "hac_lag", "event_id", "event_label", "event_date", "shock_type", "origin",
  "contrast", "estimate_log", "se_log", "z", "p_value", "p_holm_six_events",
  "effect_pct", "ci95_low_pct", "ci95_high_pct", "adj_r_squared"
)]
write_csv(effects, file.path(table_dir, "Table_S4_4_All_FRM_Definitions_All_Contrasts_HAC90.csv"))
write_csv(
  effects[effects$series_id == "adjusted_screened", ],
  file.path(table_dir, "Table_4_4a_Primary_Reference_Adjusted_Event_Effects_HAC90.csv")
)
write_csv(
  effects[effects$contrast == "acute_to_transmission_0_30_vs_baseline", ],
  file.path(table_dir, "Table_4_4b_FRM_Definition_Robustness_HAC90.csv")
)
write_csv(
  effects[effects$series_id %in% c("adjusted_robust_scaled", "usd_only_robust_scaled") &
            effects$contrast == "acute_to_transmission_0_30_vs_baseline", ],
  file.path(table_dir, "Table_4_4f_Window_Robust_Scaling_Sensitivity_HAC90.csv")
)

# Decompose the USD-only divergence into (i) aggregation of non-USD target
# lambdas and (ii) re-estimation of the network after non-USD variables are
# removed. The embedded subindex averages only the eight USD-target lambdas
# estimated inside the full reference-adjusted eleven-coin system.
embedded_usd_effects <- fit_event_model(
  log(daily$adjusted_full_network_usd_target_subindex),
  "adjusted_full_network_usd_target_subindex", 90L
)
embedded_usd_effects$p_holm_six_events <- ave(
  embedded_usd_effects$p_value, embedded_usd_effects$contrast,
  FUN = function(v) p.adjust(v, method = "holm")
)
decomposition_contrasts <- list(
  non_usd_target_aggregation = log(
    daily$adjusted_full_network_usd_target_subindex / daily$adjusted_screened
  ),
  network_reestimation = log(
    daily$usd_only_screened / daily$adjusted_full_network_usd_target_subindex
  )
)
decomposition <- do.call(rbind, lapply(names(decomposition_contrasts), function(id) {
  fit_event_model(decomposition_contrasts[[id]], id, 90L)
}))
decomposition$p_holm_six_events <- ave(
  decomposition$p_value, decomposition$series_id, decomposition$contrast,
  FUN = function(v) p.adjust(v, method = "holm")
)
decomposition <- merge(
  decomposition,
  events[, c("event_id", "event_label", "event_date", "shock_type", "origin")],
  by = "event_id", all.x = TRUE, sort = FALSE
)
decomposition$interpretation <- ifelse(
  decomposition$series_id == "non_usd_target_aggregation",
  "positive: the eight USD-target subindex inside the full adjusted network rises more (or falls less) than the full eleven-target adjusted FRM",
  "positive: independently re-estimating the eight-coin USD-only network raises the event response relative to the same eight target lambdas embedded in the full adjusted network"
)
embedded_out <- merge(
  embedded_usd_effects,
  events[, c("event_id", "event_label", "event_date", "shock_type", "origin")],
  by = "event_id", all.x = TRUE, sort = FALSE
)
write_csv(
  embedded_out[embedded_out$contrast == "acute_to_transmission_0_30_vs_baseline", ],
  file.path(table_dir, "Table_4_4d_Embedded_USD_Target_Subindex_HAC90.csv")
)
write_csv(
  decomposition[decomposition$contrast == "acute_to_transmission_0_30_vs_baseline", ],
  file.path(table_dir, "Table_4_4e_USD_Only_Divergence_Decomposition_HAC90.csv")
)
write_csv(decomposition, file.path(table_dir, "Table_S4_4_USD_Only_Divergence_All_Windows.csv"))

# Innovation: a paired benchmark-contamination contrast. Because raw and
# reference-adjusted FRM use the same eleven coins and identical estimator,
# modelling log(FRM_raw / FRM_adjusted) isolates event-window divergence caused
# by the benchmark definition rather than coin-sample composition.
contamination_specs <- list(
  benchmark_contamination_screened = log(daily$raw_usd_screened / daily$adjusted_screened),
  benchmark_contamination_strict = log(daily$raw_usd_strict / daily$adjusted_strict),
  usd_sample_composition_screened = log(daily$usd_only_screened / daily$adjusted_screened),
  usd_sample_composition_robust_scaled = log(
    daily$usd_only_robust_scaled / daily$adjusted_robust_scaled
  )
)
contamination <- do.call(rbind, lapply(names(contamination_specs), function(id) {
  fit_event_model(contamination_specs[[id]], id, 90L)
}))
contamination$p_holm_six_events <- ave(
  contamination$p_value, contamination$series_id, contamination$contrast,
  FUN = function(v) p.adjust(v, method = "holm")
)
contamination <- merge(contamination,
                       events[, c("event_id", "event_label", "event_date", "shock_type", "origin")],
                       by = "event_id", all.x = TRUE, sort = FALSE)
contamination$interpretation <- ifelse(
  grepl("benchmark_contamination", contamination$series_id),
  "positive: raw-USD FRM rises more (or falls less) than the same-coin reference-adjusted FRM",
  "positive: USD-only FRM rises more (or falls less) than the adjusted eleven-coin FRM; includes sample composition"
)
write_csv(
  contamination[contamination$contrast == "acute_to_transmission_0_30_vs_baseline", ],
  file.path(table_dir, "Table_4_4c_Benchmark_Contamination_and_Composition_Contrasts_HAC90.csv")
)
write_csv(contamination, file.path(table_dir, "Table_S4_4_Paired_Definition_Contrasts_All_Windows.csv"))

# Reference-adjusted peg validation with the identical segmented design.
fit_level_event_model <- function(y, outcome_label, unit, hac_lag = 90L) {
  if (any(!is.finite(y))) stop("Non-finite peg outcome: ", outcome_label)
  fit <- lm.fit(x = X, y = y)
  beta <- setNames(as.numeric(fit$coefficients), colnames(X))
  vcov <- newey_west_vcov(X, fit$residuals, lag = hac_lag)
  dimnames(vcov) <- list(colnames(X), colnames(X))
  contrast_names <- c("acute_0_7_vs_baseline", "acute_to_transmission_0_30_vs_baseline")
  do.call(rbind, lapply(events$event_id, function(eid) {
    do.call(rbind, lapply(contrast_names, function(cn) {
      cvec <- contrast_vector(eid, cn, names(beta))
      estimate <- sum(cvec * beta)
      se <- sqrt(as.numeric(t(cvec) %*% vcov %*% cvec))
      z <- estimate / se
      data.frame(
        outcome = outcome_label, unit = unit, hac_lag = hac_lag,
        event_id = eid, contrast = cn, estimate = estimate, se = se, z = z,
        p_value = 2 * pnorm(abs(z), lower.tail = FALSE),
        ci95_low = estimate - qnorm(0.975) * se,
        ci95_high = estimate + qnorm(0.975) * se,
        stringsAsFactors = FALSE
      )
    }))
  }))
}

peg_effects <- rbind(
  fit_level_event_model(daily$peg_mean_downside_bps, "Mean downside peg deviation", "basis points"),
  fit_level_event_model(daily$peg_depeg_breadth_1pct, "Downside-depeg breadth", "number of coins at least 1% below peg")
)
peg_effects$p_holm_six_events <- ave(
  peg_effects$p_value, peg_effects$outcome, peg_effects$contrast,
  FUN = function(v) p.adjust(v, method = "holm")
)
peg_effects <- merge(peg_effects,
                     events[, c("event_id", "event_label", "event_date", "shock_type", "origin")],
                     by = "event_id", all.x = TRUE, sort = FALSE)
write_csv(peg_effects, file.path(table_dir, "Table_4_6_Reference_Adjusted_Peg_Validation_HAC90.csv"))

# HAC-lag sensitivity for the primary adjusted 0-to-30-day effect.
lag_grid <- c(30L, 60L, 90L, 120L)
lag_sensitivity <- do.call(rbind, lapply(lag_grid, function(L) {
  z <- fit_event_model(daily$log_adjusted_screened, "adjusted_screened", L)
  z[z$contrast == "acute_to_transmission_0_30_vs_baseline", ]
}))
lag_sensitivity$p_holm_six_events_within_lag <- ave(
  lag_sensitivity$p_value, lag_sensitivity$hac_lag,
  FUN = function(v) p.adjust(v, method = "holm")
)
lag_sensitivity <- merge(lag_sensitivity,
                         events[, c("event_id", "event_label", "event_date", "shock_type")],
                         by = "event_id", all.x = TRUE, sort = FALSE)
write_csv(lag_sensitivity, file.path(table_dir, "Table_S4_4_HAC_Lag_Sensitivity_Adjusted.csv"))

get_date_rows <- function(date, offsets) match(date + offsets, daily$date)
safe_mean <- function(x) if (any(is.finite(x))) mean(x, na.rm = TRUE) else NA_real_
safe_max <- function(x) if (any(is.finite(x))) max(x, na.rm = TRUE) else NA_real_

event_time_rows <- list()
signature_rows <- list()
contribution_rows <- list()

for (i in seq_len(nrow(events))) {
  eid <- events$event_id[i]
  e_date <- events$event_date[i]
  offsets <- -60:60
  didx <- get_date_rows(e_date, offsets)
  if (anyNA(didx)) stop("Incomplete event window for ", eid)
  pre_idx <- get_date_rows(e_date, stages$baseline)
  post_idx <- get_date_rows(e_date, 0:30)
  pers_idx <- get_date_rows(e_date, stages$persistence)

  lambda_pre_history <- which(lambdas$date >= e_date - 365 & lambdas$date <= e_date - 8)
  if (length(lambda_pre_history) < 90L) lambda_pre_history <- which(lambdas$date <= e_date - 8)
  q80 <- apply(lambda_mat[lambda_pre_history, , drop = FALSE], 2, quantile,
               probs = 0.8, na.rm = TRUE, type = 7)
  lambda_window_idx <- match(e_date + offsets, lambdas$date)
  lambda_post_idx <- match(e_date + 0:30, lambdas$date)
  breadth <- rowSums(sweep(lambda_mat[lambda_window_idx, , drop = FALSE], 2, q80, ">"), na.rm = TRUE)

  post_lambda <- lambda_mat[lambda_post_idx, , drop = FALSE]
  contrib_sum <- colSums(post_lambda, na.rm = TRUE)
  contrib_share <- contrib_sum / sum(contrib_sum)
  top_col <- names(contrib_share)[which.max(contrib_share)]
  for (j in seq_along(contrib_share)) {
    contribution_rows[[length(contribution_rows) + 1L]] <- data.frame(
      event_id = eid, event_label = events$event_label[i],
      coin = unname(coin_labels[names(contrib_share)[j]]),
      lambda_sum_0_30 = contrib_sum[j],
      contribution_share_0_30 = contrib_share[j],
      rank = rank(-contrib_share, ties.method = "first")[j],
      stringsAsFactors = FALSE
    )
  }

  loo_cols <- setdiff(seq_along(coin_columns), match(top_col, coin_columns))
  loo_daily <- rowMeans(lambda_mat[, loo_cols, drop = FALSE], na.rm = TRUE)
  loo_pct <- 100 * (safe_mean(loo_daily[match(e_date + 0:30, lambdas$date)]) /
                      safe_mean(loo_daily[match(e_date + stages$baseline, lambdas$date)]) - 1)
  main_effect <- effects[
    effects$series_id == "adjusted_screened" & effects$event_id == eid &
      effects$contrast == "acute_to_transmission_0_30_vs_baseline", , drop = FALSE
  ]
  contamination_effect <- contamination[
    contamination$series_id == "benchmark_contamination_screened" &
      contamination$event_id == eid &
      contamination$contrast == "acute_to_transmission_0_30_vs_baseline", , drop = FALSE
  ]

  frm_pre <- safe_mean(daily$adjusted_screened[pre_idx])
  frm_post <- safe_mean(daily$adjusted_screened[post_idx])
  peak_local <- post_idx[which.max(daily$adjusted_screened[post_idx])]
  signature_rows[[i]] <- data.frame(
    event_id = eid, event_label = events$event_label[i], event_date = format(e_date),
    shock_type = events$shock_type[i], origin = events$origin[i],
    adjusted_frm_pre_mean = frm_pre,
    adjusted_frm_0_30_mean = frm_post,
    adjusted_frm_31_60_mean = safe_mean(daily$adjusted_screened[pers_idx]),
    adjusted_frm_descriptive_change_0_30_pct = 100 * (frm_post / frm_pre - 1),
    adjusted_frm_hac90_effect_0_30_pct = main_effect$effect_pct,
    adjusted_frm_hac90_ci95_low_pct = main_effect$ci95_low_pct,
    adjusted_frm_hac90_ci95_high_pct = main_effect$ci95_high_pct,
    adjusted_frm_hac90_p = main_effect$p_value,
    adjusted_frm_hac90_p_holm = main_effect$p_holm_six_events,
    raw_vs_adjusted_contamination_effect_pct = contamination_effect$effect_pct,
    raw_vs_adjusted_contamination_p_holm = contamination_effect$p_holm_six_events,
    adjusted_frm_peak_0_30 = daily$adjusted_screened[peak_local],
    adjusted_frm_peak_date_0_30 = format(daily$date[peak_local]),
    top_adjusted_lambda_contributor = unname(coin_labels[top_col]),
    top_adjusted_lambda_contribution_share_0_30 = unname(contrib_share[top_col]),
    adjusted_lambda_contribution_hhi_0_30 = sum(contrib_share^2),
    adjusted_lambda_breadth_q80_mean_0_30 = safe_mean(breadth[offsets %in% 0:30]),
    adjusted_lambda_breadth_q80_peak_0_30 = safe_max(breadth[offsets %in% 0:30]),
    adjusted_daily_lambda_max_share_mean_0_30 = safe_mean(daily$lambda_max_share[post_idx]),
    adjusted_daily_lambda_hhi_mean_0_30 = safe_mean(daily$lambda_hhi[post_idx]),
    adjusted_leave_top_coin_out_change_0_30_pct = loo_pct,
    peg_mean_downside_pre_bps = safe_mean(daily$peg_mean_downside_bps[pre_idx]),
    peg_mean_downside_0_30_bps = safe_mean(daily$peg_mean_downside_bps[post_idx]),
    peg_depeg_breadth_1pct_mean_pre = safe_mean(daily$peg_depeg_breadth_1pct[pre_idx]),
    peg_depeg_breadth_1pct_peak_0_30 = safe_max(daily$peg_depeg_breadth_1pct[post_idx]),
    peg_max_downside_bps_0_30 = safe_max(daily$peg_max_downside_bps[post_idx]),
    adjusted_frm_peg_spearman_0_30 = suppressWarnings(cor(
      daily$adjusted_screened[post_idx], daily$peg_mean_downside_bps[post_idx],
      method = "spearman", use = "pairwise.complete.obs"
    )),
    stringsAsFactors = FALSE
  )

  for (series_id in c("adjusted_screened", "usd_only_screened", "raw_usd_screened")) {
    pre_mean <- safe_mean(daily[[series_id]][pre_idx])
    event_time_rows[[length(event_time_rows) + 1L]] <- data.frame(
      event_id = eid, event_label = events$event_label[i], shock_type = events$shock_type[i],
      origin = events$origin[i], event_date = format(e_date),
      series_id = series_id,
      date = format(daily$date[didx]), event_time = offsets,
      frm = daily[[series_id]][didx],
      frm_index_pre100 = 100 * daily[[series_id]][didx] / pre_mean,
      adjusted_lambda_breadth_q80 = breadth,
      adjusted_lambda_max_share = daily$lambda_max_share[didx],
      peg_mean_downside_bps = daily$peg_mean_downside_bps[didx],
      peg_depeg_breadth_1pct = daily$peg_depeg_breadth_1pct[didx],
      stringsAsFactors = FALSE
    )
  }
}

event_time_data <- do.call(rbind, event_time_rows)
signatures <- do.call(rbind, signature_rows)
contributions <- do.call(rbind, contribution_rows)
contributions <- contributions[order(contributions$event_id, contributions$rank), ]
write_csv(event_time_data, file.path(bundle_dir, "source_data", "Source_Data_Figure_4_4.csv"))
write_csv(signatures, file.path(table_dir, "Table_4_5_Adjusted_FRM_Shock_Signatures.csv"))
write_csv(contributions, file.path(table_dir, "Table_S4_5_Adjusted_Lambda_Contributions.csv"))

# Cross-definition breadth, concentration and formal leave-one-out inference.
# This diagnoses cases in which a definition-level FRM effect is driven by a
# single coin. Each event removes its own largest 0-to-30-day lambda contributor;
# Holm correction is applied across the six event-specific leave-one-out tests
# within each FRM definition.
lambda_definition_manifest <- data.frame(
  definition_id = c("reference_adjusted_11", "usd_only_8", "raw_usd_11"),
  frm_series_id = c("adjusted_screened", "usd_only_screened", "raw_usd_screened"),
  lambda_file = c(
    file.path(frm_dir, "reference_adjusted_11", "lambdas_numerical_screened.csv"),
    file.path(frm_dir, "usd_only_8", "lambdas_numerical_screened.csv"),
    file.path(raw_dir, "lambdas_wide.csv")
  ),
  stringsAsFactors = FALSE
)
definition_signature_rows <- list()
definition_contribution_rows <- list()
for (s in seq_len(nrow(lambda_definition_manifest))) {
  definition_id <- lambda_definition_manifest$definition_id[s]
  frm_series_id <- lambda_definition_manifest$frm_series_id[s]
  ldef <- read_csv_checked(lambda_definition_manifest$lambda_file[s], "date")
  ldef$date <- parse_date(ldef$date)
  lcols <- setdiff(names(ldef), "date")
  if (!all(lcols %in% names(coin_labels))) stop("Unmapped lambda columns for ", definition_id)
  lmat <- as.matrix(ldef[, lcols, drop = FALSE])
  storage.mode(lmat) <- "numeric"
  if (any(lmat < 0, na.rm = TRUE)) stop("Negative lambdas for ", definition_id)

  for (i in seq_len(nrow(events))) {
    eid <- events$event_id[i]
    e_date <- events$event_date[i]
    hist <- which(ldef$date >= e_date - 365 & ldef$date <= e_date - 8)
    if (length(hist) < 90L) hist <- which(ldef$date <= e_date - 8)
    q80 <- apply(lmat[hist, , drop = FALSE], 2, quantile, probs = 0.8, na.rm = TRUE, type = 7)
    post <- match(e_date + 0:30, ldef$date)
    pre <- match(e_date + stages$baseline, ldef$date)
    contribution <- colSums(lmat[post, , drop = FALSE], na.rm = TRUE)
    share <- contribution / sum(contribution)
    baseline_contribution <- colSums(lmat[pre, , drop = FALSE], na.rm = TRUE)
    baseline_share <- baseline_contribution / sum(baseline_contribution)
    top_index <- which.max(share)
    top_col <- lcols[top_index]
    breadth <- rowSums(sweep(lmat[post, , drop = FALSE], 2, q80, ">"), na.rm = TRUE)
    leave_top <- rowMeans(lmat[, -top_index, drop = FALSE], na.rm = TRUE)
    names(leave_top) <- format(ldef$date)
    leave_top_daily <- leave_top[match(format(daily$date), names(leave_top))]
    if (any(!is.finite(leave_top_daily)) || any(leave_top_daily <= 0)) {
      stop("Invalid leave-one-out FRM for ", definition_id, " / ", eid)
    }
    leave_fit <- fit_event_model(
      log(leave_top_daily), paste0(definition_id, "_leave_", top_col), 90L
    )
    leave_row <- leave_fit[
      leave_fit$event_id == eid &
        leave_fit$contrast == "acute_to_transmission_0_30_vs_baseline", , drop = FALSE
    ]
    full_row <- effects[
      effects$series_id == frm_series_id & effects$event_id == eid &
        effects$contrast == "acute_to_transmission_0_30_vs_baseline", , drop = FALSE
    ]

    definition_signature_rows[[length(definition_signature_rows) + 1L]] <- data.frame(
      definition_id = definition_id,
      frm_series_id = frm_series_id,
      event_id = eid,
      event_label = events$event_label[i],
      coin_count = ncol(lmat),
      full_frm_hac90_effect_pct = full_row$effect_pct,
      full_frm_hac90_ci95_low_pct = full_row$ci95_low_pct,
      full_frm_hac90_ci95_high_pct = full_row$ci95_high_pct,
      full_frm_hac90_p_holm = full_row$p_holm_six_events,
      top_lambda_contributor = unname(coin_labels[top_col]),
      top_lambda_contribution_share_0_30 = unname(share[top_index]),
      lambda_contribution_hhi_0_30 = sum(share^2),
      lambda_breadth_q80_mean_0_30 = mean(breadth),
      lambda_breadth_q80_peak_0_30 = max(breadth),
      non_usd_lambda_share_0_30 = if (any(lcols %in% c("stasis_eurs", "rupiah_token", "pax_gold"))) {
        sum(share[lcols %in% c("stasis_eurs", "rupiah_token", "pax_gold")])
      } else NA_real_,
      leave_top_descriptive_change_0_30_pct = 100 * (mean(leave_top[post]) / mean(leave_top[pre]) - 1),
      leave_top_hac90_effect_0_30_pct = leave_row$effect_pct,
      leave_top_hac90_ci95_low_pct = leave_row$ci95_low_pct,
      leave_top_hac90_ci95_high_pct = leave_row$ci95_high_pct,
      leave_top_hac90_p = leave_row$p_value,
      stringsAsFactors = FALSE
    )
    for (j in seq_along(lcols)) {
      definition_contribution_rows[[length(definition_contribution_rows) + 1L]] <- data.frame(
        definition_id = definition_id,
        event_id = eid,
        event_label = events$event_label[i],
        coin = unname(coin_labels[lcols[j]]),
        lambda_sum_baseline = baseline_contribution[j],
        contribution_share_baseline = baseline_share[j],
        lambda_sum_0_30 = contribution[j],
        contribution_share_0_30 = share[j],
        coin_lambda_mean_change_0_30_pct = 100 * (
          mean(lmat[post, j], na.rm = TRUE) / mean(lmat[pre, j], na.rm = TRUE) - 1
        ),
        rank = rank(-share, ties.method = "first")[j],
        stringsAsFactors = FALSE
      )
    }
  }
}
definition_signatures <- do.call(rbind, definition_signature_rows)
definition_signatures$leave_top_hac90_p_holm_six_events <- ave(
  definition_signatures$leave_top_hac90_p, definition_signatures$definition_id,
  FUN = function(v) p.adjust(v, method = "holm")
)
definition_contributions <- do.call(rbind, definition_contribution_rows)
definition_contributions <- definition_contributions[
  order(definition_contributions$definition_id, definition_contributions$event_id,
        definition_contributions$rank),
]
write_csv(
  definition_signatures,
  file.path(table_dir, "Table_4_5b_Cross_Definition_Breadth_Concentration_and_Leave_One_Out.csv")
)
write_csv(
  definition_contributions,
  file.path(table_dir, "Table_S4_5_Cross_Definition_Lambda_Contributions.csv")
)

# Iran-Hormuz macro-financial mechanism panel. Oil prices and macro series are
# carried over non-trading days using past observations only. This remains a
# descriptive mechanism diagnostic, not an additional event hypothesis test.
macro_hormuz <- read_csv_checked(
  file.path(raw_dir, "macro_hormuz_daily.csv"),
  c("date", "DXY.Curncy", "SPX.Index", "VIX.Index")
)
wti <- read_csv_checked(file.path(raw_dir, "FRED_DCOILWTICO.csv"), c("observation_date", "DCOILWTICO"))
brent <- read_csv_checked(file.path(raw_dir, "FRED_DCOILBRENTEU.csv"), c("observation_date", "DCOILBRENTEU"))
macro_hormuz$date <- parse_date(macro_hormuz$date)
wti$observation_date <- parse_date(wti$observation_date)
brent$observation_date <- parse_date(brent$observation_date)
names(wti) <- c("date", "WTI_USD_per_barrel")
names(brent) <- c("date", "Brent_USD_per_barrel")

locf_past <- function(x) {
  for (i in seq_along(x)) if (i > 1L && !is.finite(x[i])) x[i] <- x[i - 1L]
  x
}
hormuz_date <- events$event_date[events$event_id == "hormuz"]
mechanism_calendar <- data.frame(date = seq(hormuz_date - 70, hormuz_date + 60, by = "day"))
mechanism <- Reduce(function(x, y) merge(x, y, by = "date", all.x = TRUE), list(
  mechanism_calendar,
  daily[, c("date", "adjusted_screened", "adjusted_full_network_usd_target_subindex",
            "usd_only_screened", "raw_usd_screened", "adjusted_robust_scaled",
            "usd_only_robust_scaled")],
  macro_hormuz[, c("date", "DXY.Curncy", "SPX.Index", "VIX.Index")],
  wti, brent
))
mechanism_variables <- c(
  "adjusted_screened", "adjusted_full_network_usd_target_subindex",
  "usd_only_screened", "raw_usd_screened", "adjusted_robust_scaled",
  "usd_only_robust_scaled",
  "Brent_USD_per_barrel", "WTI_USD_per_barrel", "VIX.Index", "DXY.Curncy", "SPX.Index"
)
for (v in mechanism_variables) {
  mechanism[[v]] <- suppressWarnings(as.numeric(mechanism[[v]]))
  mechanism[[v]] <- locf_past(mechanism[[v]])
}
mechanism$event_time <- as.integer(mechanism$date - hormuz_date)
mechanism <- mechanism[mechanism$event_time >= -60 & mechanism$event_time <= 60, ]
if (any(!is.finite(as.matrix(mechanism[, mechanism_variables])))) stop("Incomplete Hormuz mechanism window.")
pre_mechanism <- mechanism$event_time %in% stages$baseline
for (v in mechanism_variables) {
  mechanism[[paste0(v, "_pre100")]] <- 100 * mechanism[[v]] / mean(mechanism[[v]][pre_mechanism])
}
write_csv(mechanism, file.path(bundle_dir, "source_data", "Source_Data_Figure_4_4d_Hormuz_Mechanism.csv"))

mechanism_labels <- c(
  adjusted_screened = "Reference-adjusted FRM",
  adjusted_full_network_usd_target_subindex = "USD targets inside adjusted full network",
  usd_only_screened = "USD-only FRM",
  raw_usd_screened = "Raw USD-quoted FRM",
  adjusted_robust_scaled = "Reference-adjusted robust-scaled FRM",
  usd_only_robust_scaled = "USD-only robust-scaled FRM",
  Brent_USD_per_barrel = "Brent spot oil",
  WTI_USD_per_barrel = "WTI spot oil", VIX.Index = "VIX",
  DXY.Curncy = "U.S. Dollar Index", SPX.Index = "S&P 500"
)
mechanism_units <- c(
  adjusted_screened = "FRM index", adjusted_full_network_usd_target_subindex = "FRM subindex",
  usd_only_screened = "FRM index", raw_usd_screened = "FRM index",
  adjusted_robust_scaled = "standardized FRM index",
  usd_only_robust_scaled = "standardized FRM index",
  Brent_USD_per_barrel = "USD per barrel", WTI_USD_per_barrel = "USD per barrel",
  VIX.Index = "index points", DXY.Curncy = "index points", SPX.Index = "index points"
)
hormuz_summary <- do.call(rbind, lapply(mechanism_variables, function(v) {
  pre <- mechanism[[v]][mechanism$event_time %in% stages$baseline]
  acute <- mechanism[[v]][mechanism$event_time %in% stages$acute]
  post <- mechanism[[v]][mechanism$event_time %in% 0:30]
  post_rows <- which(mechanism$event_time %in% 0:30)
  peak_row <- which.max(post)
  data.frame(
    series = unname(mechanism_labels[v]), unit = unname(mechanism_units[v]),
    pre_mean_minus60_minus8 = mean(pre), acute_mean_0_7 = mean(acute),
    acute_change_pct = 100 * (mean(acute) / mean(pre) - 1),
    post_mean_0_30 = mean(post), post_change_pct = 100 * (mean(post) / mean(pre) - 1),
    peak_0_30 = max(post), peak_date_0_30 = format(mechanism$date[post_rows[peak_row]]),
    inference_scope = "descriptive mechanism diagnostic; not a separate event test",
    stringsAsFactors = FALSE
  )
}))
write_csv(hormuz_summary, file.path(table_dir, "Table_4_7_Hormuz_Macro_Mechanism_Descriptives.csv"))

coverage_qa <- do.call(rbind, lapply(seq_len(nrow(events)), function(i) {
  data.frame(
    event_id = events$event_id[i], event_date = format(events$event_date[i]),
    baseline_days = sum(daily$date %in% (events$event_date[i] + stages$baseline)),
    anticipation_days = sum(daily$date %in% (events$event_date[i] + stages$anticipation)),
    acute_days = sum(daily$date %in% (events$event_date[i] + stages$acute)),
    transmission_days = sum(daily$date %in% (events$event_date[i] + stages$transmission)),
    persistence_days = sum(daily$date %in% (events$event_date[i] + stages$persistence)),
    stringsAsFactors = FALSE
  )
}))
write_csv(coverage_qa, file.path(qa_dir, "event_window_coverage.csv"))

qa <- data.frame(
  check = c(
    "all_frm_series_complete_and_positive", "adjusted_lambda_dates_unique",
    "event_windows_nonoverlapping", "design_matrix_full_rank", "all_events_have_full_windows",
    "adjusted_lambdas_nonnegative", "paired_contamination_uses_same_coin_sample",
    "hormuz_mechanism_complete", "primary_multiple_testing_family_declared"
  ),
  status = c(
    if (all(vapply(series_manifest$series_id, function(id) all(is.finite(daily[[id]]) & daily[[id]] > 0), logical(1)))) "PASS" else "FAIL",
    if (!anyDuplicated(lambdas$date)) "PASS" else "FAIL",
    if (all(rowSums(stage_matrix) <= 1L)) "PASS" else "FAIL",
    if (qr(X)$rank == ncol(X)) "PASS" else "FAIL",
    if (all(as.matrix(coverage_qa[, 3:7]) == matrix(c(53, 7, 8, 23, 30), nrow(coverage_qa), 5, byrow = TRUE))) "PASS" else "FAIL",
    if (all(lambda_mat >= 0, na.rm = TRUE)) "PASS" else "FAIL",
    "PASS",
    if (nrow(mechanism) == 121L && all(is.finite(as.matrix(mechanism[, mechanism_variables])))) "PASS" else "FAIL",
    "PASS"
  ),
  detail = c(
    paste(nrow(daily), "common calendar days across", nrow(series_manifest), "definitions"),
    paste(nrow(lambdas), "days"), max(rowSums(stage_matrix)), paste(qr(X)$rank, "of", ncol(X)),
    paste(apply(coverage_qa[, 3:7], 2, range), collapse = "; "),
    paste(range(lambda_mat, na.rm = TRUE), collapse = " to "),
    "raw and adjusted contamination contrast uses the identical eleven coins; USD-only contrast is separately labelled composition-sensitive",
    paste(nrow(mechanism), "days and", length(mechanism_variables), "series"),
    "Holm adjustment across the six pre-specified events within each outcome/contrast; reference-adjusted screened FRM is primary"
  ),
  stringsAsFactors = FALSE
)
write_csv(qa, file.path(qa_dir, "event_study_QA.csv"))

statistical_scope <- c(
  "Primary outcome: log reference-adjusted eleven-coin numerically screened FRM.",
  "Independent observational unit: calendar day; rolling 90-day windows induce serial dependence.",
  "Model: global segmented regression with year fixed effects and a linear time trend.",
  "Inference: Newey-West HAC covariance with 90 lags; 30/60/120 lag sensitivity reported.",
  "Multiplicity: Holm correction across the six pre-specified events within each outcome and contrast family.",
  "Benchmark-contamination innovation: event model for log(raw-USD FRM/reference-adjusted FRM) using the same eleven coins.",
  "USD-only difference is a sample-composition robustness contrast and is not interpreted as pure benchmark contamination.",
  "Reference-adjusted peg deviations validate whether FRM movements coincide with economically meaningful peg stress.",
  "Scale sensitivity: all active returns are median-centered and MAD-scaled using only each trailing 90-day estimation window; this is a separately labelled method extension, not the supplied FRM definition.",
  "Claims are event-timed associations, not causal treatment effects."
)
writeLines(statistical_scope, file.path(qa_dir, "event_study_statistical_scope.txt"), useBytes = TRUE)
capture.output(sessionInfo(), file = file.path(qa_dir, "event_study_session_info.txt"))
if (any(qa$status != "PASS")) stop("Event-study QA failed.")
message("Three-definition event study completed: ", bundle_dir)
