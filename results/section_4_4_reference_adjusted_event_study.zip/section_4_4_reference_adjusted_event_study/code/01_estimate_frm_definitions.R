#!/usr/bin/env Rscript

# Re-estimate the full FRM system for the reference-adjusted eleven-coin panel
# and the independently estimated eight-coin USD-pegged panel. The estimator,
# rolling window, quantile, path length, macro block, missing-return rule, GACV
# rule, and deterministic jitter seed follow the audited strict reconstruction.

options(stringsAsFactors = FALSE, digits = 15, warn = 1, scipen = 999)

script_path <- function() {
  hit <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (!length(hit)) stop("Run this file with Rscript.")
  normalizePath(sub("^--file=", "", hit[1]), mustWork = TRUE)
}

code_dir <- dirname(script_path())
bundle_dir <- dirname(code_dir)
raw_dir <- file.path(bundle_dir, "source_data", "raw")
prepared_dir <- file.path(bundle_dir, "source_data", "prepared")
frm_root <- file.path(bundle_dir, "source_data", "frm")
qa_dir <- file.path(bundle_dir, "qa")
dir.create(frm_root, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

algorithm_file <- file.path(code_dir, "FRM_Statistics_Algorithm.R")
if (!file.exists(algorithm_file)) stop("Missing FRM algorithm file.")
source(algorithm_file)

window_length <- 90L
tau <- 0.05
path_steps <- 25L
n_macro_factors <- 5L
date_start_source <- as.Date("2020-01-02")
date_end_source <- as.Date("2026-05-31")
seed_base <- 20260531L
numerical_sensitivity_ratio <- 20
macro_names <- c("BV010082.Index", "CVIX.Index", "DXY.Curncy", "SPX.Index", "VIX.Index")

requested_cores <- suppressWarnings(as.integer(Sys.getenv("FRM_CORES", "")))
if (!is.finite(requested_cores) || requested_cores < 1L) {
  detected <- parallel::detectCores(logical = FALSE)
  if (!is.finite(detected)) detected <- 1L
  requested_cores <- max(1L, min(4L, detected - 1L))
}
if (.Platform$OS.type == "windows") requested_cores <- 1L

specifications <- list(
  reference_adjusted_11 = list(
    price_file = file.path(prepared_dir, "Stable_Price_reference_adjusted_11.csv"),
    stablecoin_names = c(
      "usd_coin", "binance_usd", "gemini_dollar", "stasis_eurs",
      "rupiah_token", "tether", "nusd", "pax_gold", "true_usd",
      "paxos_standard", "dai"
    ),
    interpretation = "Main: PAXG/XAUUSD, EURS/EURUSD and IDRT/IDRUSD before returns",
    window_standardization = FALSE
  ),
  usd_only_8 = list(
    price_file = file.path(prepared_dir, "Stable_Price_USD_only_8.csv"),
    stablecoin_names = c(
      "usd_coin", "binance_usd", "gemini_dollar", "tether",
      "nusd", "true_usd", "paxos_standard", "dai"
    ),
    interpretation = "Robustness: independently re-estimated system of eight USD-pegged coins",
    window_standardization = FALSE
  ),
  reference_adjusted_11_robust_scaled = list(
    price_file = file.path(prepared_dir, "Stable_Price_reference_adjusted_11.csv"),
    stablecoin_names = c(
      "usd_coin", "binance_usd", "gemini_dollar", "stasis_eurs",
      "rupiah_token", "tether", "nusd", "pax_gold", "true_usd",
      "paxos_standard", "dai"
    ),
    interpretation = "Method extension sensitivity: adjusted eleven-coin system with window-local median/MAD scaling",
    window_standardization = TRUE
  ),
  usd_only_8_robust_scaled = list(
    price_file = file.path(prepared_dir, "Stable_Price_USD_only_8.csv"),
    stablecoin_names = c(
      "usd_coin", "binance_usd", "gemini_dollar", "tether",
      "nusd", "true_usd", "paxos_standard", "dai"
    ),
    interpretation = "Method extension sensitivity: USD-only system with window-local median/MAD scaling",
    window_standardization = TRUE
  )
)

write_csv <- function(x, path, quote = TRUE) {
  write.csv(x, path, row.names = FALSE, quote = quote, na = "", fileEncoding = "UTF-8")
}

parse_panel_date <- function(x) {
  out <- suppressWarnings(as.Date(x, "%m/%d/%Y"))
  miss <- is.na(out)
  if (any(miss)) out[miss] <- suppressWarnings(as.Date(x[miss]))
  if (anyNA(out)) stop("Date parsing failed.")
  out
}

read_panel <- function(path) {
  if (!file.exists(path)) stop("Missing input: ", path)
  x <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  if (ncol(x) < 2L || !nrow(x)) stop("Malformed panel: ", path)
  x[[1]] <- parse_panel_date(x[[1]])
  names(x)[1] <- "date"
  for (nm in names(x)[-1]) x[[nm]] <- suppressWarnings(as.numeric(x[[nm]]))
  x
}

# Exact reproduction of zoo::na.locf(x, fromLast = TRUE, na.rm = FALSE) used
# by the supplied macro-data wrapper. This is retained for comparability and
# disclosed as a potential look-ahead limitation.
locf_from_last <- function(x) {
  x <- as.numeric(x)
  next_value <- NA_real_
  for (i in rev(seq_along(x))) {
    if (is.finite(x[i])) next_value <- x[i] else if (is.finite(next_value)) x[i] <- next_value
  }
  x
}

mktcap_all <- read_panel(file.path(raw_dir, "Stable_Mktcap_20260531.csv"))
macro <- read_panel(file.path(raw_dir, "Stable_Macro_20260531.csv"))
if (!identical(names(macro)[-1], macro_names)) stop("Unexpected macro columns.")

estimate_specification <- function(spec_id, spec) {
  message("\n=== Estimating ", spec_id, " ===")
  prices <- read_panel(spec$price_file)
  stablecoin_names <- spec$stablecoin_names
  n_stablecoins <- length(stablecoin_names)
  if (!identical(names(prices)[-1], stablecoin_names)) {
    stop("Unexpected price columns for ", spec_id)
  }
  if (!identical(prices$date, mktcap_all$date) || !identical(prices$date, macro$date)) {
    stop("Panel dates do not align for ", spec_id)
  }
  if (!all(stablecoin_names %in% names(mktcap_all))) stop("Missing market-cap columns.")

  dates <- prices$date
  ticker <- as.integer(format(dates, "%Y%m%d"))
  price_values <- as.matrix(prices[, stablecoin_names, drop = FALSE])
  storage.mode(price_values) <- "numeric"
  mktcap_values <- as.matrix(mktcap_all[, stablecoin_names, drop = FALSE])
  storage.mode(mktcap_values) <- "numeric"
  macro_values_raw <- as.matrix(macro[, macro_names, drop = FALSE])
  storage.mode(macro_values_raw) <- "numeric"

  if (!all(price_values[is.finite(price_values)] > 0)) stop("Non-positive price in ", spec_id)
  if (!all(mktcap_values[is.finite(mktcap_values)] >= 0)) stop("Negative market cap in ", spec_id)
  if (!all(macro_values_raw[is.finite(macro_values_raw)] > 0)) stop("Non-positive macro level.")

  macro_values <- apply(macro_values_raw, 2L, locf_from_last)
  if (is.null(dim(macro_values))) macro_values <- matrix(macro_values, ncol = 1L)
  colnames(macro_values) <- macro_names
  if (any(!is.finite(macro_values))) stop("Macro missingness remains after supplied fill rule.")

  mktcap_values[!is.finite(mktcap_values)] <- 0
  all_return_unfiltered <- diff(log(cbind(price_values, macro_values)))
  nonfinite_return_counts <- colSums(!is.finite(all_return_unfiltered))
  all_return <- all_return_unfiltered
  all_return[!is.finite(all_return)] <- 0
  stock_return <- all_return[, stablecoin_names, drop = FALSE]
  macro_return <- all_return[, macro_names, drop = FALSE]

  mktcap_index <- t(apply(mktcap_values, 1L, function(v) order(v, decreasing = TRUE)))
  storage.mode(mktcap_index) <- "integer"
  N0 <- which(dates >= date_start_source)[1]
  N1 <- tail(which(dates <= date_end_source), 1)
  if (!is.finite(N0) || !is.finite(N1) || N0 + window_length > N1) stop("Invalid range.")
  day_indices <- seq.int(N0 + window_length, N1)

  process_day <- function(t) {
    set.seed(seed_base + ticker[t])
    biggest_index <- as.integer(mktcap_index[t, seq_len(n_stablecoins)])
    rows_ret <- (t - window_length):(t - 1L)
    selected_coin_names <- colnames(stock_return)[biggest_index]
    X <- cbind(
      stock_return[rows_ret, biggest_index, drop = FALSE],
      macro_return[rows_ret, , drop = FALSE]
    )
    X[!is.finite(X)] <- 0
    X <- X[, colSums(X != 0) > 0, drop = FALSE]
    if (isTRUE(spec$window_standardization)) {
      centers <- apply(X, 2L, median, na.rm = TRUE)
      scales <- vapply(seq_len(ncol(X)), function(j) {
        mad(X[, j], center = centers[j], constant = 1.4826, na.rm = TRUE)
      }, numeric(1))
      names(scales) <- colnames(X)
      fallback <- !is.finite(scales) | scales <= 1e-12
      if (any(fallback)) {
        sd_scales <- apply(X[, fallback, drop = FALSE], 2L, sd, na.rm = TRUE)
        scales[fallback] <- sd_scales
      }
      scales[!is.finite(scales) | scales <= 1e-12] <- 1
      X <- sweep(sweep(X, 2L, centers, "-"), 2L, scales, "/")
    }
    M_t <- ncol(X)
    coin_pos <- which(colnames(X) %in% selected_coin_names)
    selected_lambdas <- setNames(rep(NA_real_, M_t), colnames(X))
    sensitivity_lambdas <- selected_lambdas
    diagnostics <- vector("list", M_t)

    for (k in seq_len(M_t)) {
      fit_error <- NA_character_
      est <- tryCatch(
        suppressWarnings(FRM_Quantile_Regression(as.matrix(X), k, tau, path_steps)),
        error = function(e) {
          fit_error <<- conditionMessage(e)
          NULL
        }
      )

      selected_row <- sensitivity_row <- NA_integer_
      selected_gacv <- selected_lambda <- sensitivity_lambda <- NA_real_
      path_length <- 0L
      condition_number <- NA_real_
      reversal_count <- NA_integer_
      sensitivity_rejected_raw <- FALSE

      if (!is.null(est)) {
        gacv <- as.numeric(est$Cgacv)
        lambda_path <- abs(as.numeric(est$lambda))
        finite_rows <- which(is.finite(gacv) & is.finite(lambda_path))
        path_length <- length(lambda_path)
        condition_number <- as.numeric(est$FRM_Condition)
        reversal_count <- if (length(lambda_path) > 1L) {
          sum(diff(lambda_path) > 1e-12, na.rm = TRUE)
        } else 0L

        if (length(finite_rows)) {
          selected_row <- finite_rows[which.min(gacv[finite_rows])]
          selected_gacv <- gacv[selected_row]
          selected_lambda <- lambda_path[selected_row]
          selected_lambdas[k] <- selected_lambda

          ranked_rows <- finite_rows[order(gacv[finite_rows], finite_rows)]
          sensitivity_row <- ranked_rows[1]
          for (candidate in ranked_rows) {
            if (candidate == 1L) {
              sensitivity_row <- candidate
              break
            }
            prior <- lambda_path[seq_len(candidate - 1L)]
            prior <- prior[is.finite(prior)]
            if (!length(prior) ||
                lambda_path[candidate] <= numerical_sensitivity_ratio * max(min(prior), 1e-12)) {
              sensitivity_row <- candidate
              break
            }
          }
          sensitivity_lambda <- lambda_path[sensitivity_row]
          sensitivity_lambdas[k] <- sensitivity_lambda
          sensitivity_rejected_raw <- !identical(sensitivity_row, selected_row)
        } else {
          fit_error <- "No finite GACV/lambda pair"
        }
      }

      diagnostics[[k]] <- data.frame(
        date = format(dates[t]),
        target = colnames(X)[k],
        target_type = if (colnames(X)[k] %in% selected_coin_names) "stablecoin" else "macro",
        selected_row = selected_row,
        selected_path_step = selected_row - 1L,
        path_length = path_length,
        selected_gacv = selected_gacv,
        selected_lambda = selected_lambda,
        sensitivity_row = sensitivity_row,
        sensitivity_lambda = sensitivity_lambda,
        sensitivity_rejected_raw = sensitivity_rejected_raw,
        condition_number = condition_number,
        lambda_path_reversals = reversal_count,
        error = fit_error,
        stringsAsFactors = FALSE
      )
    }

    list(
      date = dates[t],
      coin_lambdas = selected_lambdas[coin_pos],
      coin_lambdas_sensitivity = sensitivity_lambdas[coin_pos],
      diagnostics = do.call(rbind, diagnostics)
    )
  }

  message(
    "Estimating ", length(day_indices), " rolling days; ", n_stablecoins,
    " stablecoins + ", n_macro_factors, " macro factors; ", requested_cores, " core(s)."
  )
  batch_size <- 100L
  batches <- split(day_indices, ceiling(seq_along(day_indices) / batch_size))
  daily <- list()
  completed <- 0L
  for (b in seq_along(batches)) {
    idx <- batches[[b]]
    piece <- if (requested_cores > 1L) {
      parallel::mclapply(
        idx, process_day, mc.cores = requested_cores,
        mc.preschedule = TRUE, mc.set.seed = FALSE
      )
    } else {
      lapply(idx, process_day)
    }
    daily <- c(daily, piece)
    completed <- completed + length(piece)
    message("  ", spec_id, ": ", completed, "/", length(day_indices),
            " through ", format(dates[max(idx)]))
  }
  names(daily) <- vapply(daily, function(x) format(x$date), character(1))

  lambda_matrix <- matrix(
    NA_real_, nrow = length(daily), ncol = n_stablecoins,
    dimnames = list(names(daily), stablecoin_names)
  )
  sensitivity_matrix <- lambda_matrix
  for (i in seq_along(daily)) {
    v <- daily[[i]]$coin_lambdas
    if (length(v)) lambda_matrix[i, names(v)] <- as.numeric(v)
    vs <- daily[[i]]$coin_lambdas_sensitivity
    if (length(vs)) sensitivity_matrix[i, names(vs)] <- as.numeric(vs)
  }
  effective_coins <- rowSums(is.finite(lambda_matrix))
  frm <- apply(lambda_matrix, 1L, function(v) mean(v[is.finite(v)]))
  frm_sensitivity <- apply(sensitivity_matrix, 1L, function(v) mean(v[is.finite(v)]))
  out_dates <- as.Date(rownames(lambda_matrix))

  frm_strict <- data.frame(date = out_dates, frm = frm, effective_coins = effective_coins)
  frm_screened <- data.frame(
    date = out_dates, frm = frm_sensitivity,
    effective_coins = rowSums(is.finite(sensitivity_matrix))
  )
  lambdas_strict <- data.frame(date = out_dates, lambda_matrix, check.names = FALSE)
  lambdas_screened <- data.frame(date = out_dates, sensitivity_matrix, check.names = FALSE)
  diagnostics <- do.call(rbind, lapply(daily, `[[`, "diagnostics"))

  spec_out <- file.path(frm_root, spec_id)
  dir.create(spec_out, recursive = TRUE, showWarnings = FALSE)
  write_csv(frm_strict, file.path(spec_out, "frm_strict.csv"), quote = FALSE)
  write_csv(frm_screened, file.path(spec_out, "frm_numerical_screened.csv"), quote = FALSE)
  write_csv(lambdas_strict, file.path(spec_out, "lambdas_strict.csv"), quote = FALSE)
  write_csv(lambdas_screened, file.path(spec_out, "lambdas_numerical_screened.csv"), quote = FALSE)
  write_csv(diagnostics, file.path(spec_out, "target_diagnostics.csv"))

  model_failures <- sum(nzchar(diagnostics$error[!is.na(diagnostics$error)]))
  qa <- data.frame(
    specification = spec_id,
    check = c(
      "all_daily_frm_finite", "expected_coin_lambdas_each_day",
      "no_target_model_failures", "complete_estimation_dates",
      "minimum_finite_gacv_row_mapping", "numerical_screening_separately_labelled"
    ),
    status = c(
      if (all(is.finite(frm_strict$frm)) && all(is.finite(frm_screened$frm))) "PASS" else "FAIL",
      if (all(effective_coins == n_stablecoins) &&
          all(frm_screened$effective_coins == n_stablecoins)) "PASS" else "FAIL",
      if (model_failures == 0L) "PASS" else "FAIL",
      if (min(out_dates) == as.Date("2020-04-01") && max(out_dates) == date_end_source &&
          length(out_dates) == 2252L) "PASS" else "FAIL",
      "PASS", "PASS"
    ),
    detail = c(
      paste(sum(is.finite(frm_strict$frm)), "strict and", sum(is.finite(frm_screened$frm)), "screened values"),
      paste("effective range", min(effective_coins), "to", max(effective_coins), "; expected", n_stablecoins),
      paste(model_failures, "failed fits of", nrow(diagnostics)),
      paste(format(min(out_dates)), "to", format(max(out_dates)), ";", length(out_dates), "days"),
      "finite_rows[which.min(gacv[finite_rows])]",
      paste(sum(diagnostics$sensitivity_rejected_raw, na.rm = TRUE), "target paths and",
            sum(abs(frm_screened$frm - frm_strict$frm) > 1e-15), "FRM days changed")
    ),
    stringsAsFactors = FALSE
  )
  write_csv(qa, file.path(spec_out, "estimation_QA.csv"))

  summary <- data.frame(
    specification = spec_id,
    series = rep(c("strict", "numerical_screened"), each = 6L),
    metric = rep(c("observations", "minimum", "median", "mean", "maximum", "maximum_date"), 2L),
    value = c(
      nrow(frm_strict), min(frm_strict$frm), median(frm_strict$frm), mean(frm_strict$frm),
      max(frm_strict$frm), format(frm_strict$date[which.max(frm_strict$frm)]),
      nrow(frm_screened), min(frm_screened$frm), median(frm_screened$frm), mean(frm_screened$frm),
      max(frm_screened$frm), format(frm_screened$date[which.max(frm_screened$frm)])
    ),
    stringsAsFactors = FALSE
  )
  write_csv(summary, file.path(spec_out, "estimation_summary.csv"))

  coverage <- data.frame(
    specification = spec_id,
    series = c(stablecoin_names, macro_names),
    type = c(rep("stablecoin", n_stablecoins), rep("macro", n_macro_factors)),
    nonfinite_log_returns_set_to_zero = as.integer(nonfinite_return_counts),
    stringsAsFactors = FALSE
  )
  write_csv(coverage, file.path(spec_out, "return_coverage.csv"))

  metadata <- c(
    paste0("run_time_utc=", format(Sys.time(), tz = "UTC", usetz = TRUE)),
    paste0("specification=", spec_id),
    paste0("interpretation=", spec$interpretation),
    paste0("estimation_start=", format(min(out_dates))),
    paste0("estimation_end=", format(max(out_dates))),
    paste0("rolling_window=", window_length),
    paste0("tau=", tau),
    paste0("path_steps=", path_steps),
    paste0("stablecoins=", n_stablecoins),
    paste0("stablecoin_names=", paste(stablecoin_names, collapse = ";")),
    paste0("window_standardization=", if (isTRUE(spec$window_standardization)) {
      "median-centered and MAD-scaled within each trailing 90-day window; fallback to SD then 1; sensitivity only"
    } else "none"),
    paste0("macro_factors=", n_macro_factors),
    "macro_timing=contemporaneous_daily_log_changes_as_in_supplied_code",
    "macro_missing_rule=backward carry from future observation as in supplied code; disclosed limitation",
    "price_missing_return_rule=non-finite log returns set to zero as in supplied code",
    "gacv_rule=minimum_finite_gacv_with_correct_original_row_mapping",
    "strict_post_estimation_filtering=none",
    paste0("separate_numerical_screening_ratio=", numerical_sensitivity_ratio),
    paste0("algorithm_md5=", unname(tools::md5sum(algorithm_file))),
    paste0("price_md5=", unname(tools::md5sum(spec$price_file))),
    paste0("market_cap_md5=", unname(tools::md5sum(file.path(raw_dir, "Stable_Mktcap_20260531.csv")))),
    paste0("macro_md5=", unname(tools::md5sum(file.path(raw_dir, "Stable_Macro_20260531.csv"))))
  )
  writeLines(metadata, file.path(spec_out, "estimation_metadata.txt"), useBytes = TRUE)
  if (any(qa$status != "PASS")) stop("Estimation QA failed for ", spec_id)
  invisible(list(strict = frm_strict, screened = frm_screened, qa = qa, summary = summary))
}

spec_filter <- trimws(Sys.getenv("FRM_SPEC_FILTER", ""))
selected_spec_ids <- names(specifications)
if (nzchar(spec_filter)) {
  selected_spec_ids <- intersect(selected_spec_ids, trimws(strsplit(spec_filter, ",", fixed = TRUE)[[1]]))
  if (!length(selected_spec_ids)) stop("FRM_SPEC_FILTER matched no specifications.")
}
all_results <- lapply(selected_spec_ids, function(id) {
  estimate_specification(id, specifications[[id]])
})
names(all_results) <- selected_spec_ids

qa_files <- list.files(frm_root, pattern = "^estimation_QA\\.csv$", recursive = TRUE, full.names = TRUE)
summary_files <- list.files(frm_root, pattern = "^estimation_summary\\.csv$", recursive = TRUE, full.names = TRUE)
combined_qa <- do.call(rbind, lapply(qa_files, function(f) read.csv(f, check.names = FALSE)))
combined_summary <- do.call(rbind, lapply(summary_files, function(f) read.csv(f, check.names = FALSE)))
write_csv(combined_qa, file.path(qa_dir, "FRM_reestimation_QA.csv"))
write_csv(combined_summary, file.path(qa_dir, "FRM_reestimation_summary.csv"))
capture.output(sessionInfo(), file = file.path(qa_dir, "FRM_reestimation_session_info.txt"))
message("\nAll reference-adjusted FRM definitions completed successfully.")
