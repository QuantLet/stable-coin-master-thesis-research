#!/usr/bin/env Rscript

# Nature-style, R-only figure for the upstream reference-adjusted FRM event study.

options(stringsAsFactors = FALSE, digits = 15, warn = 1, scipen = 999)

script_path <- function() {
  hit <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (!length(hit)) stop("Run this file with Rscript.")
  normalizePath(sub("^--file=", "", hit[1]), mustWork = TRUE)
}

code_dir <- dirname(script_path())
bundle_dir <- dirname(code_dir)
source_dir <- file.path(bundle_dir, "source_data")
table_dir <- file.path(bundle_dir, "tables")
figure_dir <- file.path(bundle_dir, "figures")
qa_dir <- file.path(bundle_dir, "qa")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

read_checked <- function(path, required = character()) {
  if (!file.exists(path)) stop("Missing figure input: ", path)
  x <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  absent <- setdiff(required, names(x))
  if (length(absent)) stop("Missing columns in ", basename(path), ": ", paste(absent, collapse = ", "))
  x
}

event_time <- read_checked(
  file.path(source_dir, "Source_Data_Figure_4_4.csv"),
  c("event_id", "event_label", "series_id", "event_time", "frm_index_pre100")
)
effects <- read_checked(
  file.path(table_dir, "Table_4_4b_FRM_Definition_Robustness_HAC90.csv"),
  c("series_id", "event_id", "event_label", "effect_pct", "ci95_low_pct", "ci95_high_pct")
)
signatures <- read_checked(
  file.path(table_dir, "Table_4_5_Adjusted_FRM_Shock_Signatures.csv"),
  c("event_id", "top_adjusted_lambda_contribution_share_0_30",
    "adjusted_lambda_breadth_q80_peak_0_30", "peg_depeg_breadth_1pct_peak_0_30")
)
mechanism <- read_checked(
  file.path(source_dir, "Source_Data_Figure_4_4d_Hormuz_Mechanism.csv"),
  c("event_time", "adjusted_screened_pre100", "usd_only_screened_pre100",
    "raw_usd_screened_pre100", "Brent_USD_per_barrel_pre100", "VIX.Index_pre100")
)
embedded <- read_checked(
  file.path(table_dir, "Table_4_4d_Embedded_USD_Target_Subindex_HAC90.csv"),
  c("event_id", "effect_pct", "ci95_low_pct", "ci95_high_pct")
)
definition_signatures <- read_checked(
  file.path(table_dir, "Table_4_5b_Cross_Definition_Breadth_Concentration_and_Leave_One_Out.csv"),
  c("definition_id", "event_id", "top_lambda_contributor", "leave_top_hac90_effect_0_30_pct",
    "leave_top_hac90_ci95_low_pct", "leave_top_hac90_ci95_high_pct")
)
events <- read_checked(file.path(bundle_dir, "config", "events_primary.csv"), c("event_id", "event_label"))

numeric_columns <- c(
  "event_time", "frm_index_pre100", "effect_pct", "ci95_low_pct", "ci95_high_pct",
  "top_adjusted_lambda_contribution_share_0_30", "adjusted_lambda_breadth_q80_peak_0_30",
  "peg_depeg_breadth_1pct_peak_0_30", "adjusted_screened_pre100",
  "usd_only_screened_pre100", "raw_usd_screened_pre100",
  "Brent_USD_per_barrel_pre100", "VIX.Index_pre100"
)
for (nm in intersect(numeric_columns, names(event_time))) event_time[[nm]] <- as.numeric(event_time[[nm]])
for (nm in intersect(numeric_columns, names(effects))) effects[[nm]] <- as.numeric(effects[[nm]])
for (nm in intersect(numeric_columns, names(signatures))) signatures[[nm]] <- as.numeric(signatures[[nm]])
for (nm in intersect(numeric_columns, names(mechanism))) mechanism[[nm]] <- as.numeric(mechanism[[nm]])
for (nm in c("effect_pct", "ci95_low_pct", "ci95_high_pct")) embedded[[nm]] <- as.numeric(embedded[[nm]])
for (nm in c("leave_top_hac90_effect_0_30_pct", "leave_top_hac90_ci95_low_pct",
             "leave_top_hac90_ci95_high_pct")) {
  definition_signatures[[nm]] <- as.numeric(definition_signatures[[nm]])
}

if (!requireNamespace("svglite", quietly = TRUE)) stop("Package 'svglite' is required.")
if (!requireNamespace("ragg", quietly = TRUE)) stop("Package 'ragg' is required.")

# Figure contract fixed before plotting.
figure_contract <- c(
  "Core conclusion: reference-benchmark adjustment separates stablecoin lower-tail stress from movements inherited from gold and FX; inference is based on adjusted FRM, while USD-only and raw-USD definitions diagnose robustness and benchmark contamination.",
  "Figure archetype: quantitative four-panel grid.",
  "Target size: 183 mm x 155 mm; minimum text 8 pt; editable SVG/PDF plus 600-dpi PNG/TIFF.",
  "Backend: R only (base graphics; svglite/ragg export).",
  "Hero evidence: panel b compares HAC90 0-to-30-day effects across three independently defined FRM series.",
  "Temporal evidence: panel a shows event-aligned primary reference-adjusted paths.",
  "Mechanism evidence: panel c maps adjusted-lambda concentration versus breadth with reference-adjusted peg breadth.",
  "Contamination diagnostic: panel d decomposes the Iran-Hormuz result into the full adjusted index, robust-scaled sensitivities, embedded USD targets, standalone USD-only re-estimation, raw-USD definition and event-specific leave-top-coin checks.",
  "Independent unit: calendar day; Newey-West covariance accounts for serial dependence from overlapping 90-day windows.",
  "Reviewer risk: USD-only differs in sample size and is labelled composition robustness; only raw versus adjusted uses the identical eleven-coin sample.",
  "Causal boundary: event-timed association, not structural causal attribution."
)
writeLines(figure_contract, file.path(qa_dir, "figure_contract_and_statistical_scope.txt"), useBytes = TRUE)

event_colors <- c(
  kucoin = "#666666", china_crash = "#56B4E9", terra = "#D55E00",
  ftx = "#CC79A7", svb = "#009E73", hormuz = "#C23B33"
)
definition_colors <- c(
  adjusted_screened = "#0072B2", usd_only_screened = "#009E73", raw_usd_screened = "#D55E00"
)
definition_pch <- c(adjusted_screened = 21, usd_only_screened = 22, raw_usd_screened = 24)
definition_labels <- c(
  adjusted_screened = "Reference-adjusted 11-coin",
  usd_only_screened = "USD-only 8-coin",
  raw_usd_screened = "Raw USD-quoted 11-coin"
)
short_event <- c(kucoin = "KuCoin", china_crash = "China", terra = "Terra",
                 ftx = "FTX", svb = "SVB", hormuz = "Hormuz")

panel_label <- function(label) {
  mtext(label, side = 3, line = 0.3, adj = 0, font = 2, cex = 0.9)
}

draw_figure <- function() {
  old <- par(no.readonly = TRUE); on.exit(par(old), add = TRUE)
  layout(matrix(1:4, nrow = 2, byrow = TRUE), widths = c(1.08, 1), heights = c(1, 1))
  par(family = "sans", ps = base_size, mar = c(3.25, 3.65, 2.0, 0.8),
      mgp = c(1.85, 0.48, 0), tcl = -0.22, cex.axis = 0.68,
      cex.lab = 0.72, las = 1)

  # a, reference-adjusted event-aligned paths.
  z_all <- event_time[event_time$series_id == "adjusted_screened", ]
  ylim <- range(z_all$frm_index_pre100, finite = TRUE)
  plot(NA, xlim = c(-60, 60), ylim = ylim, log = "y", axes = FALSE,
       xlab = "Event time (days)", ylab = "Adjusted FRM (pre-event mean = 100)")
  rect(0, ylim[1], 30, ylim[2], col = "#EEEEEE", border = NA)
  axis(1, at = c(-60, -30, 0, 30, 60))
  log_ticks <- c(25, 40, 60, 100, 150, 250, 400)
  log_ticks <- log_ticks[log_ticks >= ylim[1] & log_ticks <= ylim[2]]
  axis(2, at = log_ticks, labels = log_ticks)
  box(bty = "l"); abline(v = 0, lty = 2, col = "#555555")
  for (eid in events$event_id) {
    z <- z_all[z_all$event_id == eid, ]
    lines(z$event_time, z$frm_index_pre100, col = event_colors[eid], lwd = 1.15)
  }
  legend("topleft", legend = events$event_label, col = event_colors[events$event_id],
         lwd = 1.25, bty = "n", cex = 0.47, ncol = 2)
  panel_label("a")

  # b, cross-definition HAC90 event effects.
  forest <- effects[effects$series_id %in% names(definition_colors), ]
  forest$event_order <- match(forest$event_id, events$event_id)
  forest <- forest[order(forest$event_order, match(forest$series_id, names(definition_colors))), ]
  base_y <- rev(seq_len(nrow(events)))
  offsets <- c(adjusted_screened = 0.22, usd_only_screened = 0,
               raw_usd_screened = -0.22)
  xr <- range(c(forest$ci95_low_pct, forest$ci95_high_pct), finite = TRUE)
  pad <- max(2, 0.06 * diff(xr))
  plot(NA, xlim = xr + c(-pad, pad), ylim = c(0.45, nrow(events) + 0.55), axes = FALSE,
       xlab = "Estimated FRM change over days 0-30 (%)", ylab = "")
  axis(1); axis(2, at = base_y, labels = events$event_label, tick = FALSE, cex.axis = 0.50)
  box(bty = "l"); abline(v = 0, lty = 2, col = "#777777")
  for (sid in names(definition_colors)) {
    zz <- forest[forest$series_id == sid, ]
    zz <- zz[match(events$event_id, zz$event_id), ]
    yy <- base_y + offsets[sid]
    segments(zz$ci95_low_pct, yy, zz$ci95_high_pct, yy,
             col = definition_colors[sid], lwd = 1.1)
    points(zz$effect_pct, yy, pch = definition_pch[sid], bg = definition_colors[sid],
           col = definition_colors[sid], cex = 0.78)
  }
  legend("bottomright", legend = definition_labels, col = definition_colors,
         pt.bg = definition_colors, pch = definition_pch, bty = "n", cex = 0.45)
  panel_label("b")

  # c, adjusted lambda breadth-concentration signature.
  bubble <- 0.85 + 0.32 * signatures$peg_depeg_breadth_1pct_peak_0_30
  x <- signatures$top_adjusted_lambda_contribution_share_0_30
  y <- signatures$adjusted_lambda_breadth_q80_peak_0_30
  plot(x, y, xlim = c(0, max(1, max(x) * 1.05)), ylim = c(0, 11), axes = FALSE,
       xlab = "Largest coin share of adjusted lambda",
       ylab = "Peak adjusted-lambda breadth")
  axis(1, at = seq(0, 1, 0.2)); axis(2, at = seq(0, 11, 2)); box(bty = "l")
  points(x, y, pch = 21, bg = event_colors[signatures$event_id], col = "white", cex = bubble)
  label_pos <- c(kucoin = 3, china_crash = 4, terra = 3, ftx = 2, svb = 4, hormuz = 3)
  text(x, y, labels = short_event[signatures$event_id], pos = label_pos[signatures$event_id],
       cex = 0.52, xpd = NA)
  mtext("Bubble size = peg-depeg breadth", side = 3, line = -0.8,
        adj = 1, cex = 0.46, col = "#555555")
  panel_label("c")

  # d, Iran-Hormuz definition and leave-top-coin decomposition.
  hormuz_full <- effects[
    effects$event_id == "hormuz" & effects$series_id %in% names(definition_colors),
  ]
  hormuz_full <- hormuz_full[match(names(definition_colors), hormuz_full$series_id), ]
  hormuz_scaled <- effects[
    effects$event_id == "hormuz" &
      effects$series_id %in% c("adjusted_robust_scaled", "usd_only_robust_scaled"),
  ]
  hormuz_scaled <- hormuz_scaled[
    match(c("adjusted_robust_scaled", "usd_only_robust_scaled"), hormuz_scaled$series_id),
  ]
  hormuz_embedded <- embedded[embedded$event_id == "hormuz", ]
  hormuz_leave <- definition_signatures[definition_signatures$event_id == "hormuz", ]
  hormuz_leave <- hormuz_leave[match(c("reference_adjusted_11", "usd_only_8", "raw_usd_11"),
                                     hormuz_leave$definition_id), ]
  d_labels <- c(
    "Adjusted 11-coin", "Adjusted, robust-scaled", "USD targets in full network",
    "USD-only 8-coin", "USD-only, robust-scaled", "Raw-USD 11-coin",
    paste0("Adjusted, leave ", hormuz_leave$top_lambda_contributor[1]),
    paste0("USD-only, leave ", hormuz_leave$top_lambda_contributor[2]),
    paste0("Raw-USD, leave ", hormuz_leave$top_lambda_contributor[3])
  )
  d_est <- c(
    hormuz_full$effect_pct[1], hormuz_scaled$effect_pct[1], hormuz_embedded$effect_pct,
    hormuz_full$effect_pct[2], hormuz_scaled$effect_pct[2], hormuz_full$effect_pct[3],
    hormuz_leave$leave_top_hac90_effect_0_30_pct
  )
  d_low <- c(
    hormuz_full$ci95_low_pct[1], hormuz_scaled$ci95_low_pct[1], hormuz_embedded$ci95_low_pct,
    hormuz_full$ci95_low_pct[2], hormuz_scaled$ci95_low_pct[2], hormuz_full$ci95_low_pct[3],
    hormuz_leave$leave_top_hac90_ci95_low_pct
  )
  d_high <- c(
    hormuz_full$ci95_high_pct[1], hormuz_scaled$ci95_high_pct[1], hormuz_embedded$ci95_high_pct,
    hormuz_full$ci95_high_pct[2], hormuz_scaled$ci95_high_pct[2], hormuz_full$ci95_high_pct[3],
    hormuz_leave$leave_top_hac90_ci95_high_pct
  )
  d_col <- c("#0072B2", "#0072B2", "#56B4E9", "#009E73", "#009E73", "#D55E00",
             "#0072B2", "#009E73", "#D55E00")
  d_pch <- c(21, 5, 23, 22, 6, 24, 1, 0, 2)
  d_y <- rev(seq_along(d_labels))
  dx <- range(c(d_low, d_high), finite = TRUE)
  dpad <- max(3, 0.06 * diff(dx))
  plot(NA, xlim = dx + c(-dpad, dpad), ylim = c(0.5, length(d_labels) + 0.5),
       xlab = "Iran-Hormuz FRM change over days 0-30 (%)", ylab = "", axes = FALSE)
  axis(1); axis(2, at = d_y, labels = d_labels, tick = FALSE, cex.axis = 0.48)
  box(bty = "l"); abline(v = 0, lty = 2, col = "#777777")
  segments(d_low, d_y, d_high, d_y, col = d_col, lwd = 1.15)
  points(d_est, d_y, pch = d_pch, bg = d_col, col = d_col, cex = 0.92)
  abline(h = 3.5, col = "#BBBBBB", lty = 3)
  panel_label("d")
}

width_mm = 183
height_mm = 155
base_size = 8
width_in <- width_mm / 25.4
height_in <- height_mm / 25.4
prefix <- file.path(figure_dir, "Figure_4_4_Reference_Adjusted_Event_Dynamics")

svglite::svglite(paste0(prefix, ".svg"), width = width_in, height = height_in,
                 bg = "white", system_fonts = list(sans = "Arial"))
draw_figure(); dev.off()

cairo_available <- capabilities("cairo") && isTRUE(tryCatch({
  test_pdf <- tempfile(fileext = ".pdf")
  grDevices::cairo_pdf(test_pdf, width = 1, height = 1, family = "Arial")
  graphics::plot.new(); grDevices::dev.off(); unlink(test_pdf)
  TRUE
}, warning = function(w) FALSE, error = function(e) FALSE))
if (cairo_available) {
  grDevices::cairo_pdf(paste0(prefix, ".pdf"), width = width_in, height = height_in, family = "Arial")
} else {
  grDevices::pdf(paste0(prefix, ".pdf"), width = width_in, height = height_in,
                 family = "Helvetica", useDingbats = FALSE)
}
draw_figure(); dev.off()

ragg::agg_png(paste0(prefix, ".png"), width = width_in, height = height_in,
              units = "in", res = 600, background = "white")
draw_figure(); dev.off()
ragg::agg_tiff(paste0(prefix, ".tiff"), width = width_in, height = height_in,
               units = "in", res = 600, compression = "lzw", background = "white")
draw_figure(); dev.off()

caption <- paste0(
  "Fig. 4.4 | Reference-adjusted event dynamics and definition robustness of stablecoin systemic stress. ",
  "a, Event-aligned paths of the primary eleven-coin FRM after dividing PAXG, EURS and IDRT prices by ",
  "XAUUSD, EURUSD and IDRUSD, respectively, before log differencing and full FRM re-estimation. Each path ",
  "is indexed to its arithmetic mean over days -60 to -8; the grey band marks days 0 to +30. b, Estimated ",
  "FRM changes over days 0 to +30 relative to days -60 to -8 for the reference-adjusted eleven-coin system, ",
  "the independently re-estimated eight-coin USD-pegged system and the legacy raw USD-quoted eleven-coin ",
  "system. Points are estimates and lines are 95% confidence intervals from a global segmented regression ",
  "with year effects, a linear trend and Newey-West covariance with 90 lags. Holm-adjusted exact p values ",
  "across the six-event family are reported in Source Data. c, Adjusted-FRM shock signatures separate the ",
  "largest coin's lambda contribution from cross-coin breadth; bubble size is the event-window peak number ",
  "of coins at least 1% below their reference-adjusted peg. d, The Iran-Hormuz episode is decomposed into the ",
  "full adjusted index, window-local robust-scaled sensitivities, the eight USD-target lambdas estimated inside ",
  "that full network, the independently re-estimated USD-only system, the raw-USD definition and event-specific ",
  "leave-top-coin checks. This separates ",
  "non-USD target aggregation, network re-estimation and single-coin concentration. Brent, WTI, VIX, DXY and ",
  "S&P 500 mechanism descriptives are reported in Table 4.7 and Source Data. The USD-only series changes coin ",
  "composition and is therefore a robustness check; the raw-versus-adjusted eleven-coin comparison isolates ",
  "benchmark-definition divergence. The observational unit is a calendar day, and estimates describe event-timed association, ",
  "not structural causality."
)
writeLines(caption, file.path(figure_dir, "Figure_4_4_caption.txt"), useBytes = TRUE)

exports <- paste0(prefix, c(".svg", ".pdf", ".png", ".tiff"))
qa <- data.frame(
  check = c("all_exports_present", "all_exports_nonempty", "source_data_complete",
            "font_size_contract", "dimensions_contract", "R_only_backend"),
  status = c(
    if (all(file.exists(exports))) "PASS" else "FAIL",
    if (all(file.info(exports)$size > 10000)) "PASS" else "FAIL",
    if (all(is.finite(event_time$frm_index_pre100)) && all(is.finite(effects$effect_pct)) &&
        all(is.finite(as.matrix(mechanism[, c("adjusted_screened_pre100", "usd_only_screened_pre100",
                                             "raw_usd_screened_pre100", "Brent_USD_per_barrel_pre100", "VIX.Index_pre100")])))) "PASS" else "FAIL",
    if (base_size >= 8) "PASS" else "FAIL",
    if (width_mm == 183 && height_mm == 155) "PASS" else "FAIL",
    "PASS"
  ),
  detail = c(
    paste(basename(exports), collapse = "; "),
    paste(file.info(exports)$size, collapse = "; "),
    paste(nrow(event_time), "event-time rows;", nrow(effects), "effect rows;", nrow(mechanism), "mechanism rows"),
    paste(base_size, "pt base"), paste(width_mm, "x", height_mm, "mm"),
    "base R graphics with svglite, cairo_pdf/pdf and ragg export devices"
  ),
  stringsAsFactors = FALSE
)
write.csv(qa, file.path(qa_dir, "figure_export_QA.csv"), row.names = FALSE, quote = TRUE)
if (any(qa$status != "PASS")) stop("Figure QA failed.")
message("Reference-adjusted Figure 4.4 exported: ", figure_dir)
