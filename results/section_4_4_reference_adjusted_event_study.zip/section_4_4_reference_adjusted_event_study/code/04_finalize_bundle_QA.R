#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE, digits = 15, warn = 1)
hit <- grep("^--file=", commandArgs(FALSE), value = TRUE)
if (!length(hit)) stop("Run this file with Rscript.")
code_dir <- dirname(normalizePath(sub("^--file=", "", hit[1]), mustWork = TRUE))
bundle_dir <- dirname(code_dir)
qa_dir <- file.path(bundle_dir, "qa")
table_dir <- file.path(bundle_dir, "tables")

write_csv <- function(x, path) {
  write.csv(x, path, row.names = FALSE, quote = TRUE, na = "", fileEncoding = "UTF-8")
}

checks <- data.frame(check = character(), status = character(), detail = character())
add_check <- function(name, ok, detail) {
  checks <<- rbind(checks, data.frame(
    check = name, status = if (isTRUE(ok)) "PASS" else "FAIL",
    detail = as.character(detail), stringsAsFactors = FALSE
  ))
}

r_files <- list.files(code_dir, pattern = "\\.R$", full.names = TRUE)
parse_ok <- vapply(r_files, function(f) {
  isTRUE(tryCatch({ invisible(parse(file = f)); TRUE }, error = function(e) FALSE))
}, logical(1))
add_check("all_R_files_parse", all(parse_ok), paste(basename(r_files), parse_ok, collapse = "; "))

required <- c(
  "Section_4_4_Writing_Logic_and_Empirical_Design_zh.md",
  "Section_4_4_Manuscript_Ready_EN.md", "METHOD_AUDIT.md", "README_zh.md",
  "figures/Figure_4_4_Reference_Adjusted_Event_Dynamics.svg",
  "figures/Figure_4_4_Reference_Adjusted_Event_Dynamics.pdf",
  "figures/Figure_4_4_Reference_Adjusted_Event_Dynamics.png",
  "figures/Figure_4_4_Reference_Adjusted_Event_Dynamics.tiff",
  "figures/Figure_4_4_FRM_Event_Responses_Redesigned.svg",
  "figures/Figure_4_4_FRM_Event_Responses_Redesigned.pdf",
  "figures/Figure_4_4_FRM_Event_Responses_Redesigned.png",
  "figures/Figure_4_4_FRM_Event_Responses_Redesigned.tiff",
  "figures/Figure_4_4_FRM_Event_Responses_Redesigned_caption.txt",
  "source_data/Source_Data_Figure_4_4_Redesigned.csv",
  "qa/Figure_4_4_Redesign_QA_Notes.txt",
  "tables/Table_4_4a_Primary_Reference_Adjusted_Event_Effects_HAC90.csv",
  "tables/Table_4_4b_FRM_Definition_Robustness_HAC90.csv",
  "tables/Table_4_4c_Benchmark_Contamination_and_Composition_Contrasts_HAC90.csv",
  "tables/Table_4_4d_Embedded_USD_Target_Subindex_HAC90.csv",
  "tables/Table_4_4e_USD_Only_Divergence_Decomposition_HAC90.csv",
  "tables/Table_4_4f_Window_Robust_Scaling_Sensitivity_HAC90.csv",
  "tables/Table_4_5b_Cross_Definition_Breadth_Concentration_and_Leave_One_Out.csv",
  "tables/Table_4_6_Reference_Adjusted_Peg_Validation_HAC90.csv",
  "tables/Table_4_7_Hormuz_Macro_Mechanism_Descriptives.csv"
)
required_paths <- file.path(bundle_dir, required)
add_check("required_deliverables_present", all(file.exists(required_paths)),
          paste(sum(file.exists(required_paths)), "of", length(required_paths)))
add_check("required_deliverables_nonempty", all(file.info(required_paths)$size > 0),
          paste(range(file.info(required_paths)$size), collapse = " to "))

qa_csvs <- list.files(qa_dir, pattern = "\\.csv$", full.names = TRUE)
# Exclude this script's own prior summary so reruns are idempotent after a
# previously interrupted or failed packaging pass.
qa_csvs <- qa_csvs[basename(qa_csvs) != "final_bundle_QA.csv"]
qa_status_rows <- do.call(rbind, lapply(qa_csvs, function(f) {
  x <- read.csv(f, check.names = FALSE, stringsAsFactors = FALSE)
  if (!"status" %in% names(x)) return(NULL)
  data.frame(file = basename(f), status = x$status, stringsAsFactors = FALSE)
}))
add_check("all_component_QA_statuses_pass", !is.null(qa_status_rows) && all(qa_status_rows$status == "PASS"),
          if (is.null(qa_status_rows)) "No status rows" else paste(table(qa_status_rows$status), collapse = "; "))

spec_ids <- c(
  "reference_adjusted_11", "usd_only_8",
  "reference_adjusted_11_robust_scaled", "usd_only_8_robust_scaled"
)
expected_targets <- c(36032L, 29276L, 36032L, 29276L)
frm_checks <- lapply(seq_along(spec_ids), function(i) {
  spec <- spec_ids[i]
  root <- file.path(bundle_dir, "source_data", "frm", spec)
  f <- read.csv(file.path(root, "frm_numerical_screened.csv"), check.names = FALSE)
  d <- read.csv(file.path(root, "target_diagnostics.csv"), check.names = FALSE)
  data.frame(
    specification = spec,
    frm_rows = nrow(f),
    frm_positive_finite = all(is.finite(f$frm) & f$frm > 0),
    target_rows = nrow(d),
    expected_target_rows = expected_targets[i],
    failed_targets = sum(nzchar(d$error[!is.na(d$error)])),
    stringsAsFactors = FALSE
  )
})
frm_checks <- do.call(rbind, frm_checks)
add_check("four_FRM_systems_complete",
          all(frm_checks$frm_rows == 2252L & frm_checks$frm_positive_finite &
              frm_checks$target_rows == frm_checks$expected_target_rows & frm_checks$failed_targets == 0L),
          paste(frm_checks$specification, frm_checks$target_rows, "targets", collapse = "; "))
write_csv(frm_checks, file.path(qa_dir, "final_FRM_system_counts.csv"))

primary <- read.csv(
  file.path(table_dir, "Table_4_4a_Primary_Reference_Adjusted_Event_Effects_HAC90.csv"),
  check.names = FALSE
)
add_check("primary_event_table_complete", nrow(primary) == 24L &&
            length(unique(primary$event_id)) == 6L && length(unique(primary$contrast)) == 4L,
          paste(nrow(primary), "rows;", length(unique(primary$event_id)), "events;",
                length(unique(primary$contrast)), "contrasts"))
add_check("primary_inference_numerically_valid",
          all(is.finite(primary$effect_pct)) &&
            all(primary$ci95_low_pct <= primary$effect_pct & primary$effect_pct <= primary$ci95_high_pct) &&
            all(primary$p_value >= 0 & primary$p_value <= 1) &&
            all(primary$p_holm_six_events >= primary$p_value & primary$p_holm_six_events <= 1),
          "finite effects; ordered confidence intervals; p values in [0,1]; Holm p not below raw p")

events <- read.csv(file.path(bundle_dir, "config", "events_primary.csv"), check.names = FALSE)
add_check("event_protocol_frozen", nrow(events) == 6L && !anyDuplicated(events$event_id),
          paste(events$event_id, collapse = "; "))

manifest_exclusions <- c(
  file.path(qa_dir, "file_manifest_md5.csv"),
  file.path(qa_dir, "final_bundle_QA.csv"),
  file.path(qa_dir, "final_bundle_summary.txt")
)
all_files <- list.files(bundle_dir, recursive = TRUE, full.names = TRUE, all.files = FALSE)
all_files <- all_files[file.info(all_files)$isdir %in% FALSE]
all_files <- setdiff(normalizePath(all_files), normalizePath(manifest_exclusions, mustWork = FALSE))
manifest <- data.frame(
  relative_path = substring(all_files, nchar(normalizePath(bundle_dir)) + 2L),
  bytes = file.info(all_files)$size,
  md5 = unname(tools::md5sum(all_files)),
  stringsAsFactors = FALSE
)
manifest <- manifest[order(manifest$relative_path), ]
write_csv(manifest, file.path(qa_dir, "file_manifest_md5.csv"))
add_check("manifest_files_nonempty", all(manifest$bytes > 0),
          paste(nrow(manifest), "files;", sum(manifest$bytes), "bytes"))

write_csv(checks, file.path(qa_dir, "final_bundle_QA.csv"))
summary_lines <- c(
  paste0("finalized_utc=", format(Sys.time(), tz = "UTC", usetz = TRUE)),
  paste0("bundle=", normalizePath(bundle_dir)),
  paste0("qa_pass=", sum(checks$status == "PASS")),
  paste0("qa_fail=", sum(checks$status == "FAIL")),
  paste0("frm_systems=", nrow(frm_checks)),
  paste0("rolling_target_regressions=", sum(frm_checks$target_rows)),
  paste0("target_failures=", sum(frm_checks$failed_targets)),
  paste0("primary_events=", length(unique(primary$event_id))),
  "nature_static_preflight=13 PASS, 1 R-syntax reminder WARN, 0 FAIL; actual R parse and run passed",
  "visual_QA=final 600-dpi PNG inspected; labels, intervals, panel layout and export boundaries accepted"
)
writeLines(summary_lines, file.path(qa_dir, "final_bundle_summary.txt"), useBytes = TRUE)
if (any(checks$status != "PASS")) stop("Final bundle QA failed.")
message("Final bundle QA passed: ", nrow(checks), " checks.")
